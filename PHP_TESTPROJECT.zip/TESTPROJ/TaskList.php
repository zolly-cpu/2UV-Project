<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';
confirm_logged_in();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Welcome to <?=PROJECT_MODULE?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <link rel="stylesheet" href="css/my.css">  

<style>
body {

}
#myDIV {
  height:800px;
  background-color:#FFFFFF;
  padding:30px;
}
#greyDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightgray;
  box-shadow:10px 10px 20px 5px grey;
  border-radius: 7px;
  opacity: 1;
}
#redDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:#996666;
  box-shadow:5px 5px 10px 5px #CC6666;
  border-radius: 7px;
  opacity: 1;
}
#blueDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightblue;
  box-shadow:5px 5px 10px 5px blue;
  border-radius: 7px;
  opacity: 1;
}
#greenDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightgreen;
  box-shadow:5px 5px 10px 5px green;
  border-radius: 7px;
  opacity: 1;
}
#transpImage {
	opacity: 0.3;
}
a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:active {
  color: black;
  background-color: transparent;
  text-decoration: none;
}
ul.no-bullets {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
</style>  
</head>	
<body class="skin-black-light sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="home.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>DM</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Welcome to </b> <?=PROJECT_MODULE?></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  <?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?> - Employee
                  <small>Since 2011</small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="home.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <menu>
	<center>
	<a href="home.php">
              <img src="img/home.gif" width="80" height="60">
              <!-- <span class="hidden-xs">User information</span> -->
            </a>
	<a href="TaskList.php">
              <img src="img/Task.jpg" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>		
	<a href="Scan.php">
              <img src="img/scan.png" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>				
	</center>		
  </menu>
  <content>


<?php
	try
	{
		$loEmplPropsToGet = array("EMPLOYEE_GROUPS");
		$loEmplValuesToGet = array();
		/* Get the properties of the employee */
		if(!$meServer->clServer_getFromTableDatabaseById("EMPLOYEE",$_SESSION['MEMBER_ID'],$loEmplPropsToGet,$loEmplValuesToGet))
		{
				echo "<BR>" . "Error getting the employee groups ... " . "</B>";
		}
		else
		{	
			
			//First get all the table information of the workstep
			$loWsProps = array();
			$loWsAlias = array();
			$loWsType = array();
			$loWsExtra = array();
			$loWsReference = array();

			if (!$meServer->clServer_getAllPropertiesFromTable("WORKSTEP", $loWsProps, $loWsAlias, $loWsType, $loWsExtra, $loWsReference))
			{
				echo "<BR>" . "Error getting the table information of workstep ... " . "</B>";
			}
		
			//If group is assigend get task for group
			if(count($loEmplValuesToGet) > 0)
			{
				if($loEmplValuesToGet[0] != "{}")
				{
					$loTemp = null;
					$loTemp = str_replace("{","",$loEmplValuesToGet[0]);
					$loTemp = str_replace("}","",$loTemp);
					$loTempArrayGroups = explode(',', $loTemp);
					//echo (string) count($loTempArrayGroups);
					
					for($k = 0; $k < count($loTempArrayGroups); $k++)
					{
						
						//Getting ws assigned for this group and not WS_STATE <> DONE
						$propWs = array("WS_ASSIGNED","WS_STATE");
						$valueWs = array($loTempArrayGroups[$k],"20");
						$typevalueWs = array("uuid","int");
						$logexpWs = array("=","IS DISTINCT FROM");
						$loIdsWorkstep = array();
						$meServer->clServer_get_ids_by_props("WORKSTEP",$propWs,$valueWs,$typevalueWs,$logexpWs,$loIdsWorkstep);
						

							for($j = 0; $j < count($loIdsWorkstep); $j++)
							{
								//echo "k:" . (string)$k . " j:" . (string)$j;
								
								$loWsPropsToGet = array("NAME",
														"WS_TECH",
														"WS_ASSIGNED",
														"WS_WORKPLACE",
														"CREATED_ON",
														"WS_STATE",
														"WS_PERFORMED_BY",
														"WS_PLANNED_START",
														"WS_PLANNED_STOP");
								$loWsValuesToGet = array();
								
								if($meServer->clServer_getFromTableDatabaseById("WORKSTEP",$loIdsWorkstep[$j],$loWsPropsToGet,$loWsValuesToGet))
								{
									if($loWsValuesToGet > 0)
									{								
										//Getting the workstep state WS_STATE
										$loWsState = null;
										for ($o = 0; $o < count($loWsPropsToGet); $o++)
										{	
											if (strtoupper($loWsPropsToGet[$o]) == strtoupper("WS_STATE"))
											{
													
													$loWsState = (int)$loWsValuesToGet[$o];
													break;
											}
										}	
										
										
										
										//enter in the list
										
										
										//Print DIV with color according the state of the workstep
										/*
										<enum name="WS_STATE">
											<state value="0" text="Nothing"/>
											<state value="10" text="Started"/>
											<state value="20" text="Done"/>
											<state value="30" text="Paused"/>
										</enum>	
										*/
										
										if ((int)$loWsState == 0)echo '<center><div id="greyDIV">';
										elseif((int)$loWsState == 10)echo '<center><div id="greenDIV">';
										elseif((int)$loWsState == 30)echo '<center><div id="blueDIV">';
										elseif((int)$loWsState == 20)echo '<center><div id="redDIV">';
										else echo '<center><div id="greyDIV">';

										
										echo '<ul class="no-bullets">';
										echo '<li class="dropdown user user-menu">';

										echo '<a href="#" class="dropdown-toggle" data-toggle="dropdown">';
										echo '<table border="0">';
										
										for ($o = 0; $o < count($loWsValuesToGet); $o++)
										{	
											$t = 0;
											for($t = 0; $t < count($loWsProps); $t++)
											{
												if (strtoupper($loWsProps[$t]) == strtoupper($loWsPropsToGet[$o])) break;
											}
											
											
											$loTempValue = null;
											$loTempName = null;
											$loPropName = null;
											if($loWsExtra[$t] == "enum")
											{
												if(strtoupper($loWsProps[$t]) == "WS_TECH") $loTempValue = getEnumValue((int)$loWsValuesToGet[$o],$WS_TECH);
												else if(strtoupper($loWsProps[$t]) == "WS_STATE")$loTempValue = getEnumValue((int)$loWsValuesToGet[$o],$WS_STATE);
												$loTempName = $loWsAlias[$t];
												$loPropName = $loWsPropsToGet[$o];
											}
											else if ($loWsReference[$t] == "no")
											{
												$loTempName = $loWsAlias[$t];
												$loTempValue = $loWsValuesToGet[$o];
												$loPropName = $loWsPropsToGet[$o];
											}
											
											if($loTempName != null && $loTempValue != null)
											{										
												if (strtoupper($loPropName) == strtoupper("NAME"))
												{
													echo '<tr>';
													echo '<th>' . $loTempName . ': ' . $loTempValue . '</th>';
													echo '<th>&nbsp;&nbsp;&nbsp;</th>';
													if ((int)$loWsState == 0)echo '<th rowspan="10"><div id="transpImage"><img src="img/stop-small.gif" width="40" height="40" class="img-circle"></div></th>';
													elseif((int)$loWsState == 10)echo '<th rowspan="10"><div id="transpImage"><img src="img/play-small.gif" width="40" height="40" class="img-circle"></div></th>';
													elseif((int)$loWsState == 30)echo '<th rowspan="10"><div id="transpImage"><img src="img/pause-small.gif" width="40" height="40" class="img-circle"></div></th>';
													elseif((int)$loWsState == 20)echo '<th rowspan="10"><div id="transpImage"><img src="img/stop-small.gif" width="40" height="40" class="img-circle"></div></th>';
													
													echo '</tr>';	
												}
												else
												{
													echo '<tr>';
													echo '<th>' . $loTempName . ': ' . $loTempValue . '</th>';
													echo '</tr>';													
												}
											}
											
										}
										
										echo '</table>';
										echo '</a>';
										

										//////////////////////// List of files ////////////////////////////////////////////////
										$loPropLinkedDocWS = array("LINKED_DOCUMENTS");
										$loValueLinkedDocWS = array();
										
										if(!$meServer->clServer_getFromTableDatabaseById("WORKSTEP",$loIdsWorkstep[$j],$loPropLinkedDocWS,$loValueLinkedDocWS))
										{
											echo "Could not get the LINKED_DOCUMENTS property ... <BR>";
										}


										echo '<hr width="90%" />';	
										echo '<table>';
										
										//analysing the array
										if ($loValueLinkedDocWS != null)
										{
										if(count($loValueLinkedDocWS) > 0)
										{
											if((string)$loValueLinkedDocWS[0] != "{}" && (string)$loValueLinkedDocWS[0] != "" && (string)$loValueLinkedDocWS[0] != null)
											{							

												
												$loTemp = null;
												$loTemp = str_replace("{","",$loValueLinkedDocWS[0]);
												$loTemp = str_replace("}","",$loTemp);
												$loTempArrayLinkeDocs = explode(',', $loTemp);


												echo '<tr>';
												echo '<th>';
												echo 'Download linked documents:';
												echo '<BR>';
												echo '<form action="download.php" method="post" enctype="multipart/form-data">';
												echo '<select id="linkedDocList" name="linkedDocList" size="' .  (string)count($loTempArrayLinkeDocs) . '">';								

												
												for($u = 0; $u < count($loTempArrayLinkeDocs); $u++)
												{
													$loPropLinkedDoc = array("PKEY","NAME");
													$loValueLinkedDoc = array();
													
													if(!$meServer->clServer_getFromTableDatabaseById("LINKEDDOC",$loTempArrayLinkeDocs[$u],$loPropLinkedDoc,$loValueLinkedDoc))
													{
														echo "Could not get the LINKEDDOC properties ... <BR>";
														
													}
													else
													{													
														echo '<option value="' . $loValueLinkedDoc[0] . '">' . $loValueLinkedDoc[1] . '</option>';
													}
												}
												
												echo '</select>';
												echo '<BR>';
												echo '<input type="submit" value="Download" name="submit">';
												echo '</form>';		
												echo '</th>';									
												echo '</tr>';							
											}						
										}
										}
										//////////////////////// End list of files ////////////////////////////////////////////////	
										//////////////////////// Upload an image or file ////////////////////////////////////////////////
										echo '<tr>';
										echo '<th>';
										echo '<BR>';
										echo 'Upload linked documents:';
										echo '<BR>';
										echo '<form action="upload.php" method="post" enctype="multipart/form-data">';
										echo '<input type="file" name="fileToUpload" id="fileToUpload">';
										echo '<input type="hidden" id="objectId" name="objectId" value="' . $loIdsWorkstep[$j] . '">';
										echo '<input type="hidden" id="objectClassName" name="objectClassName" value="WORKSTEP">';
									
										echo '<input type="submit" value="Upload Image" name="submit">';
										echo '</form>';	
										echo '</th>';									
										echo '</tr>';
										//////////////////////// End Upload an image or file ////////////////////////////////////////////////														
										
										
										echo '</table>';
										
										
										

										
										//Input the form for the actions
										echo '<ul class="dropdown-menu">';
										echo '<li class="user-header">';
										echo '<center>';
										echo '<img src="img/work.jpg" class="img-circle" alt="User Image">';
										echo '<p><small>Perform on task:</small></p>';
										echo '</center>';
										echo '</li>';
				  
										echo '<li class="user-footer">';
										echo '<div>';
										echo '<center>';
										echo '&nbsp;&nbsp;';
										if ((int)$loWsState == 0)
										{
											echo '<a href="ws_start.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">start</a>';
										}
										else if ((int)$loWsState == 10)
										{
											echo '<a href="ws_pause.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">pause</a>';
											echo '&nbsp;&nbsp;&nbsp;&nbsp;';
											echo '<a href="ws_stop.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">stop</a>';
										}
										else if ((int)$loWsState == 30)
										{
											echo '<a href="ws_start.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">start</a>';
										}
										echo '&nbsp;&nbsp;';
										echo '</center>';
										echo '</div>';
										echo '</li>';
										echo '</ul>';
										
										
										
										echo '</li>';
										echo '</ul>';
										echo '</div>';
										
										echo '</center>';																														
									}
								}
							}
					}
					
				}
			}
		}
	}
	catch(Exception $e)
	{
		
	}
	//Loop for personal tasks
	try
	{
		//First get all the table information of the workstep
		$loWsProps = array();
		$loWsAlias = array();
		$loWsType = array();
		$loWsExtra = array();
		$loWsReference = array();

		if (!$meServer->clServer_getAllPropertiesFromTable("WORKSTEP", $loWsProps, $loWsAlias, $loWsType, $loWsExtra, $loWsReference))
		{
			echo "<BR>" . "Error getting the table information of workstep ... " . "</B>";
		}
		
		//Getting ws assigned for this group and not WS_STATE <> DONE
		$propWs = array("WS_ASSIGNED","WS_STATE");
		$valueWs = array($_SESSION['MEMBER_ID'],"20");
		$typevalueWs = array("uuid","int");
		$logexpWs = array("=","IS DISTINCT FROM");
		$loIdsWorkstep = array();
		$meServer->clServer_get_ids_by_props("WORKSTEP",$propWs,$valueWs,$typevalueWs,$logexpWs,$loIdsWorkstep);

		for($j = 0; $j < count($loIdsWorkstep); $j++)
		{
			
			$loWsPropsToGet = array("NAME",
									"WS_TECH",
									"WS_ASSIGNED",
									"WS_WORKPLACE",
									"CREATED_ON",
									"WS_STATE",
									"WS_PERFORMED_BY",
									"WS_PLANNED_START",
									"WS_PLANNED_STOP");
			$loWsValuesToGet = array();
			
			if($meServer->clServer_getFromTableDatabaseById("WORKSTEP",$loIdsWorkstep[$j],$loWsPropsToGet,$loWsValuesToGet))
			{
				if($loWsValuesToGet > 0)
				{
					//Getting the workstep state WS_STATE
					$loWsState = null;
					for ($o = 0; $o < count($loWsPropsToGet); $o++)
					{	
						if (strtoupper($loWsPropsToGet[$o]) == strtoupper("WS_STATE"))
						{
								$loWsState = $loWsValuesToGet[$o];
								break;
						}
					}	
					
					
					
					//enter in the list
					
					
					//Print DIV with color according the state of the workstep
					/*
					<enum name="WS_STATE">
						<state value="0" text="Nothing"/>
						<state value="10" text="Started"/>
						<state value="20" text="Done"/>
						<state value="30" text="Paused"/>
					</enum>	
					*/
					
					if ((int)$loWsState == 0)echo '<center><div id="greyDIV">';
					elseif((int)$loWsState == 10)echo '<center><div id="greenDIV">';
					elseif((int)$loWsState == 30)echo '<center><div id="blueDIV">';
					elseif((int)$loWsState == 20)echo '<center><div id="redDIV">';

					
					echo '<ul class="no-bullets">';
					echo '<li class="dropdown user user-menu">';

					echo '<a href="#" class="dropdown-toggle" data-toggle="dropdown">';
					echo '<table border="0">';
					
					for ($o = 0; $o < count($loWsValuesToGet); $o++)
					{	
						$t = 0;
						for($t = 0; $t < count($loWsProps); $t++)
						{
							if (strtoupper($loWsProps[$t]) == strtoupper($loWsPropsToGet[$o])) break;
						}
						
						
						$loTempValue = null;
						$loTempName = null;
						$loPropName = null;
						if($loWsExtra[$t] == "enum")
						{
							if(strtoupper($loWsProps[$t]) == "WS_TECH") $loTempValue = getEnumValue((int)$loWsValuesToGet[$o],$WS_TECH);
							else if(strtoupper($loWsProps[$t]) == "WS_STATE")$loTempValue = getEnumValue((int)$loWsValuesToGet[$o],$WS_STATE);
							$loTempName = $loWsAlias[$t];
							$loPropName = $loWsPropsToGet[$o];
						}
						else if ($loWsReference[$t] == "no")
						{
							$loTempName = $loWsAlias[$t];
							$loTempValue = $loWsValuesToGet[$o];
							$loPropName = $loWsPropsToGet[$o];
						}
						
						if($loTempName != null && $loTempValue != null)
						{										
							if (strtoupper($loPropName) == strtoupper("NAME"))
							{
								echo '<tr>';
								echo '<th>' . $loTempName . ': ' . $loTempValue . '</th>';
								echo '<th>&nbsp;&nbsp;&nbsp;</th>';
								if ((int)$loWsState == 0)echo '<th rowspan="10"><div id="transpImage"><img src="img/stop-small.gif" width="40" height="40" class="img-circle"></div></th>';
								elseif((int)$loWsState == 10)echo '<th rowspan="10"><div id="transpImage"><img src="img/play-small.gif" width="40" height="40" class="img-circle"></div></th>';
								elseif((int)$loWsState == 30)echo '<th rowspan="10"><div id="transpImage"><img src="img/pause-small.gif" width="40" height="40" class="img-circle"></div></th>';
								elseif((int)$loWsState == 20)echo '<th rowspan="10"><div id="transpImage"><img src="img/stop-small.gif" width="40" height="40" class="img-circle"></div></th>';
								echo '</tr>';	
							}
							else
							{
								echo '<tr>';
								echo '<th>' . $loTempName . ': ' . $loTempValue . '</th>';
								echo '</tr>';													
							}
						}
						
					}
					echo '</table>';
					echo '</a>';



					//////////////////////// List of files ////////////////////////////////////////////////
					$loPropLinkedDocWS = array("LINKED_DOCUMENTS");
					$loValueLinkedDocWS = array();
					
					if(!$meServer->clServer_getFromTableDatabaseById("WORKSTEP",$loIdsWorkstep[$j],$loPropLinkedDocWS,$loValueLinkedDocWS))
					{
						echo "Could not get the LINKED_DOCUMENTS property ... <BR>";
					}


					echo '<hr width="90%" />';	
					echo '<table>';
					
					//analysing the array
					if ($loValueLinkedDocWS != null)
					{
					if(count($loValueLinkedDocWS) > 0)
					{
						if((string)$loValueLinkedDocWS[0] != "{}" && (string)$loValueLinkedDocWS[0] != "" && (string)$loValueLinkedDocWS[0] != null)
						{							

							
							$loTemp = null;
							$loTemp = str_replace("{","",$loValueLinkedDocWS[0]);
							$loTemp = str_replace("}","",$loTemp);
							$loTempArrayLinkeDocs = explode(',', $loTemp);


							echo '<tr>';
							echo '<th>';
							echo 'Download linked documents:';
							echo '<BR>';
							echo '<form action="download.php" method="post" enctype="multipart/form-data">';
							echo '<select id="linkedDocList" name="linkedDocList" size="' .  (string)count($loTempArrayLinkeDocs) . '">';								

							
							for($u = 0; $u < count($loTempArrayLinkeDocs); $u++)
							{
								$loPropLinkedDoc = array("PKEY","NAME");
								$loValueLinkedDoc = array();
								
								if(!$meServer->clServer_getFromTableDatabaseById("LINKEDDOC",$loTempArrayLinkeDocs[$u],$loPropLinkedDoc,$loValueLinkedDoc))
								{
									echo "Could not get the LINKEDDOC properties ... <BR>";
								}
								else
								{								
									echo '<option value="' . $loValueLinkedDoc[0] . '">' . $loValueLinkedDoc[1] . '</option>';
								}
							}
							
							echo '</select>';
							echo '<BR>';
							echo '<input type="submit" value="Download" name="submit">';
							echo '</form>';		
							echo '</th>';									
							echo '</tr>';							
						}						
					}
					}
					//////////////////////// End list of files ////////////////////////////////////////////////	
					//////////////////////// Upload an image or file ////////////////////////////////////////////////
					echo '<tr>';
					echo '<th>';
					echo '<BR>';
					echo 'Upload linked documents:';
					echo '<BR>';
					echo '<form action="upload.php" method="post" enctype="multipart/form-data">';
					echo '<input type="file" name="fileToUpload" id="fileToUpload">';
					echo '<input type="hidden" id="objectId" name="objectId" value="' . $loIdsWorkstep[$j] . '">';
					echo '<input type="hidden" id="objectClassName" name="objectClassName" value="WORKSTEP">';
				
					echo '<input type="submit" value="Upload Image" name="submit">';
					echo '</form>';	
					echo '</th>';									
					echo '</tr>';
					//////////////////////// End Upload an image or file ////////////////////////////////////////////////			
					
					
					
					echo '</table>';

					
					//Input the form for the actions
					echo '<ul class="dropdown-menu">';
					echo '<li class="user-header">';
					echo '<center>';
					echo '<img src="img/work.jpg" class="img-circle" alt="User Image">';
					echo '<p><small>Perform on task:</small></p>';
					echo '</center>';
					echo '</li>';

					echo '<li class="user-footer">';
					echo '<div>';
					echo '<center>';
					echo '&nbsp;&nbsp;';
					if ((int)$loWsState == 0)
					{
						echo '<a href="ws_start.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">start</a>';
					}
					else if ((int)$loWsState == 10)
					{
						echo '<a href="ws_pause.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">pause</a>';
						echo '&nbsp;&nbsp;&nbsp;&nbsp;';
						echo '<a href="ws_stop.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">stop</a>';
					}
					else if ((int)$loWsState == 30)
					{
						echo '<a href="ws_start.php?ws_id=' . $loIdsWorkstep[$j] . '" class="btn btn-default btn-flat">start</a>';
					}
					echo '&nbsp;&nbsp;';
					echo '</center>';
					echo '</div>';
					echo '</li>';
					echo '</ul>';
					
					
					
					echo '</li>';
					echo '</ul>';
					echo '</div>';
					
					echo '</center>';	
				}
			}
		}			
		
		
		
	}
	catch(Exception $e)
	{
		
	}
	
?>
  </content>
  
<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>


<?php
include 'footer.php';
?>

</body>
</html>
