<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';
confirm_logged_in();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Welcome to <?=PROJECT_MODULE?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <link rel="stylesheet" href="css/my.css">  

<style>
body {

}
#myDIV {
  height:800px;
  background-color:#FFFFFF;
  padding:30px;
}
#greyDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightgray;
  box-shadow:10px 10px 20px 5px grey;
  border-radius: 7px;
  opacity: 1;
}
#redDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:#996666;
  box-shadow:5px 5px 10px 5px #CC6666;
  border-radius: 7px;
  opacity: 1;
}
#blueDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightblue;
  box-shadow:5px 5px 10px 5px blue;
  border-radius: 7px;
  opacity: 1;
}
#greenDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightgreen;
  box-shadow:5px 5px 10px 5px green;
  border-radius: 7px;
  opacity: 1;
}
#transpImage {
	opacity: 0.3;
}
a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:active {
  color: black;
  background-color: transparent;
  text-decoration: none;
}
ul.no-bullets {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
</style>  
</head>	
<body class="skin-black-light sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="home.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>DM</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Welcome to </b> <?=PROJECT_MODULE?></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  <?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?> - Employee
                  <small>Since 2011</small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="home.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <menu>
	<center>
	<a href="home.php">
              <img src="img/home.gif" width="80" height="60">
              <!-- <span class="hidden-xs">User information</span> -->
            </a>
	<a href="TaskList.php">
              <img src="img/Task.jpg" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>		
	<a href="Scan.php">
              <img src="img/scan.png" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>				
	</center>		
  </menu>
  <content>


<?php

$target_dir = "//192.168.1.147/Share/FILE_LOCATION/";


$uploadOk = 1;


// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 1;
  }
}


// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
	//Get the current date
	$loDate = new DateTime();
	$loDateString = $loDate->format('Y-m-d H:i:s');
	
	//Insert into the table of LINKEDDOC
	$loLinkedDocProps = array("NAME","CREATED_ON","FILE_NAME","FILE_TYPE");
	$loLinkedDocValues = array(basename($_FILES["fileToUpload"]["name"]),$loDateString,basename($_FILES["fileToUpload"]["name"]),"0");
	$loLinkedDocTypeValues = array("text","timestamp","text","int");
	
	if(!$meServer->clServer_insertIntoTableDatabase("LINKEDDOC",$loLinkedDocProps,$loLinkedDocValues,$loLinkedDocTypeValues))
	{
			echo "<BR>" . "Error inserting file entry into the database ... " . "</B>";
	}
	else
	{	
		//Get the id of the linked doc
		$loLinkedDocPropsGet = array("NAME","CREATED_ON","FILE_NAME","FILE_TYPE");
		$loLinkedDocValuesGet = array(basename($_FILES["fileToUpload"]["name"]),$loDateString,basename($_FILES["fileToUpload"]["name"]),"0");
		$loLinkedDocTypeValuesGet = array("text","timestamp","text","int");
		$loLinkedDocLogExpGet = array("=","=","=","=");
		$loReturnIds = array();
		
		if(!$meServer->clServer_get_ids_by_props("LINKEDDOC",$loLinkedDocPropsGet,$loLinkedDocValuesGet,$loLinkedDocTypeValuesGet,$loLinkedDocLogExpGet,$loReturnIds))
		{
			echo "<BR>" . "Error getting the LINKEDDOC from database ... " . "</B>";
			die;
		}
		else
		{
			if (count($loReturnIds) == 0)
			{
				echo "<BR>" . "Error getting the LINKEDDOC from database ... " . "</B>";
				die;
			}
			
			$target_file = $target_dir . "LINKEDDOC_" . $loReturnIds[0] . "/" . basename($_FILES["fileToUpload"]["name"]);			
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
				echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				$uploadOk = 1;
			}
			
			// Check if file already exists
			if (file_exists($target_file)) {
			  echo "Sorry, file already exists.";
			  die;
			  $uploadOk = 0;
			}
			
			
			if (!is_dir($target_dir . "LINKEDDOC_" . $loReturnIds[0])) {
				if (mkdir($target_dir . "LINKEDDOC_" . $loReturnIds[0], 0777, true)) {
					echo "Directory created successfully.";
				} else {
					echo "Failed to create directory.";
					die;
				}
			} else {
				echo "Directory already exists.";
			}
			
			
			
			
			//Upload the document
			if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
			} else {
				echo "Sorry, there was an error uploading your file.";
				die;
			}
			

			//Add to object property
			$loObjectId = $_POST['objectId'];
			$loObjectClassName = $_POST['objectClassName'];
			
			//First getting the property
			$loObjectProp = array("LINKED_DOCUMENTS");
			$loObjectValue = array();

			if(!$meServer->clServer_getFromTableDatabaseById($loObjectClassName,$loObjectId,$loObjectProp,$loObjectValue))
			{
				echo "Sorry, LINKED_DOCUMENTS do not exist on this object ...";
				die;	
			}
			
			$loNewObjectValue = "";
			//analysing the array
			if(count($loObjectValue) > 0)
			{
				if($loObjectValue[0] != "{}")
				{
					$loTemp = null;
					$loTemp = str_replace("{","",$loObjectValue[0]);
					$loTemp = str_replace("}","",$loTemp);
					$loTempArrayLinkeDocs = explode(',', $loTemp);
					for($k = 0; $k < count($loTempArrayLinkeDocs); $k++)
					{
						if ($k == 0) $loNewObjectValue = $loNewObjectValue . $loTempArrayLinkeDocs[$k];
						else $loNewObjectValue = $loNewObjectValue . "$;$" . $loTempArrayLinkeDocs[$k];
					}
					$loNewObjectValue = $loNewObjectValue . "$;$" . $loReturnIds[0];
				}
				else
				{
					$loNewObjectValue = $loNewObjectValue . $loReturnIds[0];
				}
			}
			
			//Post the new value into the workstep
			$loWsProps = array("LINKED_DOCUMENTS");
			$loWsValues = array($loNewObjectValue);
			$loWsValueTypes = array("uuid[]");
			
			if (!$meServer->clServer_updateIntoTableDatabase($loObjectClassName,$loObjectId,$loWsProps,$loWsValues,$loWsValueTypes))
			{
				echo "<B>" . "Error updating the workstep ... " . "</B>";
				die;
			}
			else
			{
				
				echo '<script type="text/javascript">window.location.href="TaskList.php";</script>';

			}
		}
	}
}
?>
  </content>
  
<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>


<?php
include 'footer.php';
?>

</body>
</html>
