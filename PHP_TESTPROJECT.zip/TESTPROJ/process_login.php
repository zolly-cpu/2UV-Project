<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';

$email = validate_input(isset($_POST['email'])?$_POST['email']:'');
$password = validate_input(isset($_POST['password'])?$_POST['password']:'');
if($_SERVER['REQUEST_METHOD']==='POST' && is_array($_POST) && !empty($email) && !empty($password)){
    //get user id
	
	$loProperties = array("EMAIL","PASSWORD");
	$loValues = array($email,$password);
	$loValuesType = array("text","text");
	$loLogExp = array("=","=");
	
    $user_id = $meServer->clServer_get_id_by_props("EMPLOYEE",$loProperties,$loValues,$loValuesType,$loLogExp);
	
    //if($user_id != null){
        //if(check_brute($user_id['id'])){
        //    header( "Location: index.php?error=bG9naW4gYmxvY2tlZA==" ); die;    
        //}
    //}
	
	if(validate_user($meServer,$user_id)){
		header( "Location: home.php" ); die;		
	}else{
		//header( "Location: index.php?error=bG9naW4gZXJyb3I=" ); die;
		header( "Location: index.php" ); die;	
	}
}else{
	header( "Location: index.php" ); die;
}
include 'footer.php';
?>