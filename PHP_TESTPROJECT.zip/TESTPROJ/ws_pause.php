<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';

if($_GET['ws_id'] != null){
	/*******************************
	* Get the open operations
	********************************/
	//Getting ws assigned for this group and not WS_STATE <> DONE
	$propWs = array("OBJECT","PERFORMED_WORKSTEP","DATUM_STOP","OPERATION_STATE","OPERATION_SOURCE");
	$valueWs = array($_SESSION['MEMBER_ID'],$_GET['ws_id'],"","10","50");
	$typevalueWs = array("uuid","uuid","timestamp","int","int");
	$logexpWs = array("=","=","=","=","=");
	$loIdsWorkstep = array();
	if (!$meServer->clServer_get_ids_by_props("OPERATION",$propWs,$valueWs,$typevalueWs,$logexpWs,$loIdsWorkstep))
	{
		echo "<B>" . "Error getting the operations ... " . "</B>";
		die;	
	}
	
	for($j = 0; $j < count($loIdsWorkstep); $j++)
	{
		/*******************************
		* Update the operations
		********************************/
		$loDate = new DateTime();
		$loDateString = $loDate->format('Y-m-d H:i:s');		
		$loOpProps = array("DATUM_STOP","OPERATION_STATE","OPERATION_CLOSED_CAUSE");
		$loOpValues = array($loDateString,"20","10");
		$loOpValueTypes = array("timestamp","int","int");
		
		if (!$meServer->clServer_updateIntoTableDatabase("OPERATION",$loIdsWorkstep[$j],$loOpProps,$loOpValues,$loOpValueTypes))
		{
			echo "<B>" . "Error updating the operations ... " . "</B>";
			die;
		}		
	}
	/*
    <TABLE name="OPERATION">
      	<COLUMN name="PKEY" alias="Primary key" type="uuid" extra="" reference="no"></COLUMN>	
      	<COLUMN name="NAME" alias="Name" type="varchar(255)" extra="" reference="no"></COLUMN>
		<COLUMN name="OBJECT" alias="Performed on object" type="uuid" extra="" reference="LIVING_OBJ_MACH$;$EMPLOYEE"></COLUMN>
      	<COLUMN name="OBJECTS" alias="Included objects" type="uuid[]" extra="" 	reference="PERSON$;$CUSTOMER$;$EMPLOYEE$;$LIVING_OBJ_MACH"></COLUMN>
      	<COLUMN name="DATUM_START" alias="Start date" type="timestamp" extra="" reference="no"></COLUMN>
      	<COLUMN name="DATUM_STOP" alias="Stop date" type="timestamp" extra="" reference="no"></COLUMN>
		<COLUMN name="H2O_VALUE" alias="H2O value" type="float8" extra="" reference="no"></COLUMN>
		<COLUMN name="PERFORMED_WORKSTEP" alias="Performed workstep" type="uuid" extra="" reference="WORKSTEP"></COLUMN>
		<COLUMN name="OPERATION_STATE" alias="State of the operation" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="OPERATION_SOURCE" alias="State of the operation" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="OPERATION_CLOSED_CAUSE" alias="Why operation closed" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="OPERATION_ERROR_INFORMATION" alias="Error Information" type="text" extra="" reference="no"></COLUMN>
    </TABLE>
	
	
	<enum name="OPERATION_SOURCE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Cycle"/>
		<state value="20" text="Routine"/>
		<state value="30" text="Script"/>
		<state value="40" text="System"/>
		<state value="50" text="Browser"/>
	</enum>			
	<enum name="OPERATION_STATE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Open"/>
		<state value="20" text="Closed"/>
	</enum>	
	<enum name="OPERATION_CLOSED_CAUSE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Normal"/>
		<state value="20" text="Error"/>
	</enum>			
	*/
	
	/*******************************
	* Update the workstep
	********************************/	
	$loWsProps = array("WS_STATE");
	$loWsValues = array("30");
	$loWsValueTypes = array("int");
	
	if (!$meServer->clServer_updateIntoTableDatabase("WORKSTEP",$_GET['ws_id'],$loWsProps,$loWsValues,$loWsValueTypes))
	{
		echo "<B>" . "Error updating the workstep ... " . "</B>";
		die;
	}	
	
	
	/*
	<TABLE name="WORKSTEP">
      	<COLUMN name="PKEY" alias="Primary key" type="uuid" extra="" reference="no"></COLUMN>	
      	<COLUMN name="NAME" alias="Name" type="varchar(255)" extra="" reference="no"></COLUMN>
		<COLUMN name="WS_TECH" alias="Workstep technology" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="WS_ASSIGNED" alias="Workstep assigned to" type="uuid" extra="" reference="EMPL_GROUP$;$EMPLOYEE"></COLUMN>
		<COLUMN name="WS_WORKPLACE" alias="Workstep perforemed on workplace" type="uuid" extra="" reference="LIVING_OBJ_MACH"></COLUMN>
		<COLUMN name="CREATED_ON" alias="Creation date" type="timestamp" extra="" reference="no"></COLUMN>
		<COLUMN name="WS_STATE" alias="State of the workstep" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="WS_PERFORMED_BY" alias="Workstep done by" type="uuid" extra="" reference="EMPLOYEE"></COLUMN>
		<COLUMN name="WS_PLANNED_START" alias="Planned start" type="timestamp" extra="" reference="no"></COLUMN>
		<COLUMN name="WS_PLANNED_STOP" alias="Planned stop" type="timestamp" extra="" reference="no"></COLUMN>
    </TABLE>	
	<enum name="WS_TECH">
		<state value="0" text="Nothing"/>
		<state value="10" text="Cleaning Hall"/>
		<state value="20" text="Cleaning Room"/>
		<state value="21" text="Cleaning Floor 1"/>
		<state value="22" text="Cleaning Floor 2"/>
		<state value="23" text="Cleaning Floor 3"/>
		<state value="24" text="Cleaning Floor 4"/>
		<state value="25" text="Cleaning Floor 5"/>
		<state value="26" text="Cleaning Floor 6"/>
		<state value="27" text="Cleaning Floor 7"/>
		<state value="28" text="Cleaning Floor 8"/>
		<state value="29" text="Cleaning Floor 9"/>
		<state value="30" text="Cleaning Floor 10"/>
		<state value="100" text="Making bed"/>
		<state value="200" text="Administration"/>
		<state value="300" text="Research"/>
		<state value="500" text="Cooking breakfast"/>
		<state value="510" text="Cooking lunch"/>
		<state value="520" text="Cooking dinner"/>
	</enum>	
	<enum name="WS_STATE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Started"/>
		<state value="20" text="Done"/>
		<state value="30" text="Paused"/>
	</enum>	
	*/
	
	
	

	header( "Location: TaskList.php" ); die;
}else{
	header( "Location: index.php" ); die;
}
include 'footer.php';
?>