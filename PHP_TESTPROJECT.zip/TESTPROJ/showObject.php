<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';
confirm_logged_in();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Welcome to <?=PROJECT_MODULE?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <link rel="stylesheet" href="css/my.css">  

<style>
body {

}
#myDIV {
  height:800px;
  background-color:#FFFFFF;
  padding:30px;
}
#greyDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightgray;
  box-shadow:10px 10px 20px 5px grey;
  border-radius: 7px;
  opacity: 1;
}
#redDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:#996666;
  box-shadow:5px 5px 10px 5px #CC6666;
  border-radius: 7px;
  opacity: 1;
}
#blueDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightblue;
  box-shadow:5px 5px 10px 5px blue;
  border-radius: 7px;
  opacity: 1;
}
#greenDIV {
  margin:auto;
  margin-top:50px;
  width:300px;
  padding:10px;
  background-color:lightgreen;
  box-shadow:5px 5px 10px 5px green;
  border-radius: 7px;
  opacity: 1;
}
#transpImage {
	opacity: 0.3;
}
a:link {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: black;
  background-color: transparent;
  text-decoration: none;
}

a:active {
  color: black;
  background-color: transparent;
  text-decoration: none;
}
ul.no-bullets {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
</style>  
</head>	
<body class="skin-black-light sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="home.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>DM</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Welcome to </b> <?=PROJECT_MODULE?></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  <?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?> - Employee
                  <small>Since 2011</small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="home.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <menu>
	<center>
	<a href="home.php">
              <img src="img/home.gif" width="80" height="60">
              <!-- <span class="hidden-xs">User information</span> -->
            </a>
	<a href="TaskList.php">
              <img src="img/Task.jpg" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>		
	<a href="Scan.php">
              <img src="img/scan.png" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>				
	</center>		
  </menu>
  <content>


<?php

if($_GET['object_id'] != null)
{
	try
	{
		$loTemp = $_GET['object_id'];
		$loData = explode('$;$', $loTemp);
		if (count($loData) > 1)
		{
			$loProps = array();
			$loAlias = array();
			$loType = array();
			$loExtra = array();
			$loReference = array();

			if (!$meServer->clServer_getAllPropertiesFromTable(strtoupper($loData[0]), $loProps, $loAlias, $loType, $loExtra, $loReference))
			{
				echo "<BR><b>" . "Error getting the table information of object ... " . "</b></B>";
				die;
			}
			else
			{
				$loValuesObject = array();
				
				if(!$meServer->clServer_getFromTableDatabaseById($loData[0],$loData[1],$loProps,$loValuesObject))
				{
					echo "<BR><b>" . "Error getting the properties of object ... " . "</b></B>";
					die;				
				}
				else
				{
					echo '<center>';
					echo '<table border="0">';
					echo '<tr>';
					echo '<td colspan="2"><B><u>';
					echo $loData[0];
					echo '</B></u></td>';
					echo '</tr>';
					for ($o = 0; $o < count($loProps); $o++)
					{	
						$loTempValue = null;
						$loTempName = null;
						$loPropName = null;
						
						$loTempValue = $loValuesObject[$o];
						$loTempName = $loAlias[$o];
						$loPropName = $loProps[$o];		
						
						echo '<tr>';
						echo '<td>';
						echo $loTempName . ': ';
						echo '</td>';
						echo '<td>';
						echo $loTempValue;
						echo '</td>';
						echo '</tr>';
					}
					echo '</table>';					
					echo '</center>';

				}
			}	
		}				
	}
	catch(Exception $e)
	{
		echo "<BR><b>" . "Error getting the properties of object ... " . "</b></B>";
		die;
	}
}
?>
  </content>
  
<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>


<?php
include 'footer.php';
?>

</body>
</html>
