<?php
//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

require_once(function_exists("Ice\\initialize") ? "Ice_ns.php" : "Ice_no_ns.php");

?>
