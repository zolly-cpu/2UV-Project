<?php
$meServer = new clServer();
$meServer->clServer_Create_Connection();



/************************************
Enum values should be generated
************************************/
$WS_TECH = array (
					array(0,"Nothing"),
					array(10,"Cleaning Hall"),
					array(20,"Cleaning Room"),
					array(21,"Cleaning Floor 1"),
					array(22,"Cleaning Floor 2"),
					array(23,"Cleaning Floor 3"),
					array(24,"Cleaning Floor 4"),
					array(25,"Cleaning Floor 5"),
					array(26,"Cleaning Floor 6"),
					array(27,"Cleaning Floor 7"),
					array(28,"Cleaning Floor 8"),
					array(29,"Cleaning Floor 9"),
					array(30,"Cleaning Floor 10"),
					array(100,"Making bed"),
					array(200,"Administration"),
					array(300,"Research"),
					array(500,"Cooking breakfast"),
					array(510,"Cooking lunch"),
					array(520,"Cooking dinner")  
);
$WS_STATE = array (
					  array(0,"Nothing"),
					  array(10,"Started"),
					  array(20,"Done"),
					  array(30,"Paused")
);

?>