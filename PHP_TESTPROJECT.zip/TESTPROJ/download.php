<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';
confirm_logged_in();

if(isset($_POST["submit"])) {
	$target_dir = "//192.168.1.147/Share/FILE_LOCATION/";
	$loObjectId = $_POST['linkedDocList'];

	if ((string)$loObjectId != "")
	{
		//First getting the property
		$loObjectProp = array("FILE_NAME");
		$loObjectValue = array();

		if(!$meServer->clServer_getFromTableDatabaseById("LINKEDDOC",$loObjectId,$loObjectProp,$loObjectValue))
		{
			echo "Sorry, get LINKEDDOC query not ok ...";
			die;	
		}
		
		if (!count($loObjectValue) > 0)
		{
			echo "Sorry, get LINKEDDOC not found ...";
			die;			
		}
		$file = $target_dir . "LINKEDDOC_" . $loObjectId . "/" . (string)$loObjectValue[0];
		
        // Set headers to prompt download
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
		readfile($file);

		echo '<script type="text/javascript">window.location.href="TaskList.php";</script>';		
	}
}
header( "Location: TaskList.php" ); die;
echo '<script type="text/javascript">window.location.href="TaskList.php";</script>';		
?>