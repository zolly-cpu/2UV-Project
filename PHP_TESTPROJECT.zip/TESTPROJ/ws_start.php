<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';

if($_GET['ws_id'] != null){
	/*******************************
	* Start and operation
	********************************/
	$loProperties = array("NAME","OBJECT","DATUM_START","PERFORMED_WORKSTEP","OPERATION_STATE","OPERATION_SOURCE");
	$loDate = new DateTime();
	$loDateString = $loDate->format('Y-m-d H:i:s');	
	$loValues = array($_SESSION['LAST_NAME'] . " " . $_SESSION['FIRST_NAME'] . " PHP Task Portal",$_SESSION['MEMBER_ID'],$loDateString,$_GET['ws_id'],"10","50");
	$loTypeValues = array("varchar(255)","uuid","timestamp","uuid","int","int");
	
	if (!$meServer->clServer_insertIntoTableDatabase("OPERATION",$loProperties,$loValues,$loTypeValues))
	{
		echo "<B>" . "Error storing the operation ... " . "</B>";
		die;
	}
	/*
    <TABLE name="OPERATION">
      	<COLUMN name="PKEY" alias="Primary key" type="uuid" extra="" reference="no"></COLUMN>	
      	<COLUMN name="NAME" alias="Name" type="varchar(255)" extra="" reference="no"></COLUMN>
		<COLUMN name="OBJECT" alias="Performed on object" type="uuid" extra="" reference="LIVING_OBJ_MACH$;$EMPLOYEE"></COLUMN>
      	<COLUMN name="OBJECTS" alias="Included objects" type="uuid[]" extra="" 	reference="PERSON$;$CUSTOMER$;$EMPLOYEE$;$LIVING_OBJ_MACH"></COLUMN>
      	<COLUMN name="DATUM_START" alias="Start date" type="timestamp" extra="" reference="no"></COLUMN>
      	<COLUMN name="DATUM_STOP" alias="Stop date" type="timestamp" extra="" reference="no"></COLUMN>
		<COLUMN name="H2O_VALUE" alias="H2O value" type="float8" extra="" reference="no"></COLUMN>
		<COLUMN name="PERFORMED_WORKSTEP" alias="Performed workstep" type="uuid" extra="" reference="WORKSTEP"></COLUMN>
		<COLUMN name="OPERATION_STATE" alias="State of the operation" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="OPERATION_SOURCE" alias="State of the operation" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="OPERATION_CLOSED_CAUSE" alias="Why operation closed" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="OPERATION_ERROR_INFORMATION" alias="Error Information" type="text" extra="" reference="no"></COLUMN>
    </TABLE>
	
	
	<enum name="OPERATION_SOURCE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Cycle"/>
		<state value="20" text="Routine"/>
		<state value="30" text="Script"/>
		<state value="40" text="System"/>
		<state value="50" text="Browser"/>
	</enum>			
	<enum name="OPERATION_STATE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Open"/>
		<state value="20" text="Closed"/>
	</enum>		
	*/
	
	/*******************************
	* Update the workstep
	********************************/	
	$loWsProps = array("WS_STATE","WS_PERFORMED_BY");
	$loWsValues = array("10",$_SESSION['MEMBER_ID']);
	$loWsValueTypes = array("int","uuid");
	
	if (!$meServer->clServer_updateIntoTableDatabase("WORKSTEP",$_GET['ws_id'],$loWsProps,$loWsValues,$loWsValueTypes))
	{
		echo "<B>" . "Error updating the workstep ... " . "</B>";
		die;
	}	
	
	
	/*
	<TABLE name="WORKSTEP">
      	<COLUMN name="PKEY" alias="Primary key" type="uuid" extra="" reference="no"></COLUMN>	
      	<COLUMN name="NAME" alias="Name" type="varchar(255)" extra="" reference="no"></COLUMN>
		<COLUMN name="WS_TECH" alias="Workstep technology" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="WS_ASSIGNED" alias="Workstep assigned to" type="uuid" extra="" reference="EMPL_GROUP$;$EMPLOYEE"></COLUMN>
		<COLUMN name="WS_WORKPLACE" alias="Workstep perforemed on workplace" type="uuid" extra="" reference="LIVING_OBJ_MACH"></COLUMN>
		<COLUMN name="CREATED_ON" alias="Creation date" type="timestamp" extra="" reference="no"></COLUMN>
		<COLUMN name="WS_STATE" alias="State of the workstep" type="int" extra="enum" reference="no"></COLUMN>
		<COLUMN name="WS_PERFORMED_BY" alias="Workstep done by" type="uuid" extra="" reference="EMPLOYEE"></COLUMN>
		<COLUMN name="WS_PLANNED_START" alias="Planned start" type="timestamp" extra="" reference="no"></COLUMN>
		<COLUMN name="WS_PLANNED_STOP" alias="Planned stop" type="timestamp" extra="" reference="no"></COLUMN>
    </TABLE>	
	<enum name="WS_TECH">
		<state value="0" text="Nothing"/>
		<state value="10" text="Cleaning Hall"/>
		<state value="20" text="Cleaning Room"/>
		<state value="21" text="Cleaning Floor 1"/>
		<state value="22" text="Cleaning Floor 2"/>
		<state value="23" text="Cleaning Floor 3"/>
		<state value="24" text="Cleaning Floor 4"/>
		<state value="25" text="Cleaning Floor 5"/>
		<state value="26" text="Cleaning Floor 6"/>
		<state value="27" text="Cleaning Floor 7"/>
		<state value="28" text="Cleaning Floor 8"/>
		<state value="29" text="Cleaning Floor 9"/>
		<state value="30" text="Cleaning Floor 10"/>
		<state value="100" text="Making bed"/>
		<state value="200" text="Administration"/>
		<state value="300" text="Research"/>
		<state value="500" text="Cooking breakfast"/>
		<state value="510" text="Cooking lunch"/>
		<state value="520" text="Cooking dinner"/>
	</enum>	
	<enum name="WS_STATE">
		<state value="0" text="Nothing"/>
		<state value="10" text="Started"/>
		<state value="20" text="Done"/>
		<state value="30" text="Paused"/>
	</enum>	
	*/
	
	
	

	header( "Location: TaskList.php" ); die;
}else{
	header( "Location: index.php" ); die;
}
include 'footer.php';
?>