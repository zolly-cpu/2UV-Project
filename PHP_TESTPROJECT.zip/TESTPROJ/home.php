<?php
require("config/session.php");
require("config/constant.php");
require("config/helper.php");
require("config/clServer.php");
include 'header.php';
confirm_logged_in();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Welcome to <?=PROJECT_MODULE?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
</head>
<body class="skin-black-light sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="home.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>DM</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Welcome to </b> <?=PROJECT_MODULE?></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  <?php echo $_SESSION['FIRST_NAME']." ".$_SESSION['LAST_NAME']?> - Employee
                  <small>Since 2011</small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="home.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <menu>
	<center>
	<a href="home.php">
              <img src="img/home.gif" width="80" height="60">
              <!-- <span class="hidden-xs">User information</span> -->
            </a>
	<a href="TaskList.php">
              <img src="img/Task.jpg" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>
	<a href="Scan.php">
              <img src="img/scan.png" width="60" height="60">
              <!-- <span class="hidden-xs">Task List</span> -->
            </a>				
	</center>		
  </menu>
  <content>
<?php

  /* Getting the table information */
  $table = "EMPLOYEE";
  $loEmplProps = array();
  $loEmplAlias = array();
  $loEmplType = array();
  $loEmplExtra = array();
  $loEmplReference = array();
  
  $loEmplPropsToGet = array();
  $loEmplValuesToGet = array();
  
  
  
  if (!$meServer->clServer_getAllPropertiesFromTable($table, $loEmplProps, $loEmplAlias, $loEmplType, $loEmplExtra, $loEmplReference))
  {
		echo "<BR>" . "Error getting the table information ... " . "</B>";
  }
  else
  {
		/* Storing the known properties */
		for($i = 0; $i < count($loEmplProps); ++$i) 
		{
			$loTempProp = $loEmplProps[$i];
			$loTempRef = $loEmplReference[$i];
			$loTempAlias = $loEmplAlias[$i];
			if (strtoupper($loTempProp) == "PKEY"){}
			elseif(strtoupper($loTempProp) == "PASSWORD"){}
			elseif(strtoupper($loTempRef) != "NO"){}
			else
			{
				array_push($loEmplPropsToGet, $loTempProp);
			}
		}
	  
  }
  /* Get the properties of the employee */
  if(!$meServer->clServer_getFromTableDatabaseById($table,$_SESSION['MEMBER_ID'],$loEmplPropsToGet,$loEmplValuesToGet))
  {
		echo "<BR>" . "Error getting the employee information ... " . "</B>";
  }
  else
  {	
		echo '<center>';
		echo '<ul>';
		for($i = 0; $i < count($loEmplPropsToGet); $i++) 
		{	
			$loTempPropToGet = $loEmplPropsToGet[$i];
			$loTempValueToGet = $loEmplValuesToGet[$i];
			
	  		echo '<li class="user-footer">';
			echo '<div class="pull-left">';
            echo $loTempPropToGet;
            echo '</div>';
			//echo '</li>';
			//echo '<li>';
            echo '<div class="pull-left">';
			echo '&nbsp;&nbsp;&nbsp;&nbsp;';
            echo $loTempValueToGet;
            echo '</div>';
            echo '</li>';
			
		}
		echo '</ul>';
		echo '</center>';
  }
?>
  </content>
  
<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>




</body>
</html>
