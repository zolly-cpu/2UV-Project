#pragma once

#include <QtCore/QString>
#include "clDriverFrame.h"

typedef clDriverFrame *(*CreateModuleFn)();
