/****************************************************************************
** Meta object code from reading C++ file 'clCycleBuilderView.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.15)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "clCycleBuilderView.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'clCycleBuilderView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.15. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_clCycleBuilderView_t {
    QByteArrayData data[20];
    char stringdata0[399];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_clCycleBuilderView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_clCycleBuilderView_t qt_meta_stringdata_clCycleBuilderView = {
    {
QT_MOC_LITERAL(0, 0, 18), // "clCycleBuilderView"
QT_MOC_LITERAL(1, 19, 24), // "slotButtonRefreshPressed"
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 35), // "slotButtonCreateCycleRoutineP..."
QT_MOC_LITERAL(4, 81, 19), // "slotButtonSaveCycle"
QT_MOC_LITERAL(5, 101, 30), // "slotTreeClassItemPressedCycles"
QT_MOC_LITERAL(6, 132, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(7, 149, 4), // "item"
QT_MOC_LITERAL(8, 154, 5), // "index"
QT_MOC_LITERAL(9, 160, 32), // "slotTreeClassItemPressedRoutines"
QT_MOC_LITERAL(10, 193, 21), // "slotTreeClassItemMenu"
QT_MOC_LITERAL(11, 215, 1), // "i"
QT_MOC_LITERAL(12, 217, 34), // "slotTreeClassItemMenuRoutineC..."
QT_MOC_LITERAL(13, 252, 14), // "slotNewElement"
QT_MOC_LITERAL(14, 267, 17), // "slotDeleteElement"
QT_MOC_LITERAL(15, 285, 15), // "slotEditElement"
QT_MOC_LITERAL(16, 301, 20), // "slotNewElementCycles"
QT_MOC_LITERAL(17, 322, 23), // "slotDeleteElementCycles"
QT_MOC_LITERAL(18, 346, 21), // "slotEditElementCycles"
QT_MOC_LITERAL(19, 368, 30) // "slotDeleteElementRoutineCycles"

    },
    "clCycleBuilderView\0slotButtonRefreshPressed\0"
    "\0slotButtonCreateCycleRoutinePressed\0"
    "slotButtonSaveCycle\0slotTreeClassItemPressedCycles\0"
    "QTreeWidgetItem*\0item\0index\0"
    "slotTreeClassItemPressedRoutines\0"
    "slotTreeClassItemMenu\0i\0"
    "slotTreeClassItemMenuRoutineCycles\0"
    "slotNewElement\0slotDeleteElement\0"
    "slotEditElement\0slotNewElementCycles\0"
    "slotDeleteElementCycles\0slotEditElementCycles\0"
    "slotDeleteElementRoutineCycles"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_clCycleBuilderView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   84,    2, 0x08 /* Private */,
       3,    0,   85,    2, 0x08 /* Private */,
       4,    0,   86,    2, 0x08 /* Private */,
       5,    2,   87,    2, 0x08 /* Private */,
       9,    2,   92,    2, 0x08 /* Private */,
      10,    2,   97,    2, 0x08 /* Private */,
      12,    2,  102,    2, 0x08 /* Private */,
      13,    0,  107,    2, 0x08 /* Private */,
      14,    0,  108,    2, 0x08 /* Private */,
      15,    0,  109,    2, 0x08 /* Private */,
      16,    0,  110,    2, 0x08 /* Private */,
      17,    0,  111,    2, 0x08 /* Private */,
      18,    0,  112,    2, 0x08 /* Private */,
      19,    0,  113,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6, QMetaType::Int,    7,    8,
    QMetaType::Void, 0x80000000 | 6, QMetaType::Int,    7,    8,
    QMetaType::Void, 0x80000000 | 6, QMetaType::Int,    7,   11,
    QMetaType::Void, 0x80000000 | 6, QMetaType::Int,    7,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void clCycleBuilderView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<clCycleBuilderView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->slotButtonRefreshPressed(); break;
        case 1: _t->slotButtonCreateCycleRoutinePressed(); break;
        case 2: _t->slotButtonSaveCycle(); break;
        case 3: _t->slotTreeClassItemPressedCycles((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->slotTreeClassItemPressedRoutines((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->slotTreeClassItemMenu((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 6: _t->slotTreeClassItemMenuRoutineCycles((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->slotNewElement(); break;
        case 8: _t->slotDeleteElement(); break;
        case 9: _t->slotEditElement(); break;
        case 10: _t->slotNewElementCycles(); break;
        case 11: _t->slotDeleteElementCycles(); break;
        case 12: _t->slotEditElementCycles(); break;
        case 13: _t->slotDeleteElementRoutineCycles(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject clCycleBuilderView::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_clCycleBuilderView.data,
    qt_meta_data_clCycleBuilderView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *clCycleBuilderView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *clCycleBuilderView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_clCycleBuilderView.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int clCycleBuilderView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
