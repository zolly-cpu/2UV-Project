#include "clDriverFrame.h"
clDriverFrame::clDriverFrame()
{
    try
    {		

    }
    catch(const std::exception& ex)
    {
            printf(ex.what());       
    }	
    catch(...)
    {
        printf("clDriverFrame::clDriverFrame(vector <QString> paParameters) -> error ...");
    }
}

clDriverFrame::~clDriverFrame ()
{
}
///////////////////////////////
//Functions to be overridden //
///////////////////////////////
/*
QString clDriverFrame::doConnect(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doDisconnect(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doState(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doRun(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doAbort(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doHold(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doContinue(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doSendFile(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doReceiveFile(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doScriptCommand(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}
QString clDriverFrame::doOptionalCommand(QString paValue, QString paParameters) const
{
	QString loReturnValue;
    try
    {		
		return loReturnValue;
    }
    catch(const std::exception& ex)
    {
            printf(ex.what());
			return loReturnValue;
    }	
    catch(...)
    {
        printf("clDriverFrame::doConnect(QString paConfigFile) -> error ...");
		return loReturnValue;
    }	
}*/