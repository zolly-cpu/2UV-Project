#define INFO_BUFFER_SIZE 32767
#include "clClassLoader.h"

clClassLoader::clClassLoader(clIceClientServer * paIceClientServer, clIceClientLogging *paIceClientLogging)
{
	try
	{
		meIceClientServer = paIceClientServer;
		meIceClientLogging = paIceClientLogging;
		
		initializeLibrarys();
		readClassesFromXmlFile();
		loadClasses();
		
	}
	catch(...)
	{
		cout << "clWorkstationCycles::clWorkstationCycles -> failed" << endl;
	}
}
clClassLoader::~clClassLoader()
{
	for (int i=0; i < 500; i++)
	{
		if (meLibraryLib[i] != NULL)
		{
			cleanObjectDLL(i);
		}
	}
}
bool clClassLoader::initializeLibrarys()
{
	try
	{
		for (int i = 0; i < 500; i++)
		{
			meLibraryLib[i] = NULL;
			meCreateModuleObjectFn[i] = NULL;
		}
		meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::initializeLibrarys -> Librarys initialized");
		return true;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::initializeLibrarys -> " + QString(e.what()));
		return false;
    }	
}
bool clClassLoader::readClassesFromXmlFile()
{
	try
	{
		QString loMapLib = QString("libMap.xml");
        QFile loFile(loMapLib);
        if ( !loFile.open( QIODevice::ReadOnly ) ) 
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe",QString("clClassLoader::readClassesFromXmlFile -> Cound not open file '" + loMapLib + "' ..."));
            return false;
        }

        //QDomDocument
        QDomDocument loDomDocument;
        if ( !loDomDocument.setContent( &loFile ) ) 
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe",QString("clClassLoader::readClassesFromXmlFile -> Cound not parse file '" + loMapLib + "' ..."));
            loFile.close();
            return false;
        }

       QDomElement loDocElem = loDomDocument.documentElement();
	   
	   
       // Getting the library's
       QDomNode loTablesNode = loDocElem.firstChild();
       while( !loTablesNode.isNull() ) 
	   {
			if(loTablesNode.nodeName() == "lib")
			{
				QDomElement loTablesElem = loTablesNode.toElement();
				if (!loTablesElem.isNull())
				{
					
					QString loName = loTablesElem.attribute("name");
					if (loName.isEmpty() || loName.compare(QString("")) == 0)
					{
						meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe",QString("clClassLoader::readClassesFromXmlFile -> mapLib tag no name for node ..."));
						return false;
					}
					QString loSource = loTablesElem.attribute("source");
					if (loSource.isEmpty() || loSource.compare(QString("")) == 0)
					{
						meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe",QString("clClassLoader::readClassesFromXmlFile -> mapLib tag no source for node ..."));
						return false;
					}
					
					QString loPath = loTablesElem.attribute("path");
					if (loPath.isEmpty())
					{
						loPath = QString("");
					}					
					
					
					meClassNames.push_back(loName);
					meClassDllNames.push_back(loSource);
					meClassPaths.push_back(loPath);
					
					
					// Getting the methods
					QDomNode loTableNode = loTablesElem.firstChild();
					
					vector <QString> loMethods;
					while(!loTableNode.isNull())
					{
						QDomElement loMethodElem = loTableNode.toElement();
						if(!loMethodElem.isNull())
						{
							QString loMethodName = loMethodElem.attribute("name");
							if (loMethodName.isEmpty() || loMethodName.compare(QString("")) == 0)
							{
								meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe",QString("clClassLoader::readClassesFromXmlFile -> mapLib tag no name for method ..."));
								return false;
							}
							loMethods.push_back(loMethodName);
						}
						loTableNode = loTableNode.nextSibling();	
					}
					meClassMethods.push_back(loMethods);
				}
			}
			loTablesNode = loTablesNode.nextSibling();
	   }
		meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::readClassesFromXmlFile -> mapping file readed");
		return true;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::readClassesFromXmlFile -> " + QString(e.what()));
		return false;
    }	
}
bool clClassLoader::loadClasses()
{	
	try
	{
		for (int i = 0; i < (int) meClassDllNames.size(); i++)
		{
			//Read the class dll ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
			meObjectCall.push_back(callObjectDLL(QString(meClassPaths.at(i) + meClassDllNames.at(i)),i));
			
			//Store the database information of the class //////////////////////////////////////////////////////////////////////////////////////
			vector<std::string> loPropertyName;
			vector<std::string> loAlias;
			vector<std::string> loType;
			vector<std::string> loExtra;
			vector<std::string> loReference;
			QString loReturnMessage;
			bool loGetColumnsCycle = false;
			
			loGetColumnsCycle = meIceClientServer->getAllPropertiesFromTable(meClassNames.at(i),loPropertyName,loAlias,loType,loExtra,loReference,loReturnMessage);
			
			if (!loGetColumnsCycle) 
			{
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::loadClasses -> " + loReturnMessage);
				return false;
			}
			
			vector<clDatabaseColumn *> meDatabaseColumns;
			for (int j = 0; j < (int) loPropertyName.size(); j++)
			{
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::loadClasses() -> Propertie name [" + QString(loPropertyName[j].c_str()) + "]");
				meDatabaseColumns.push_back( new clDatabaseColumn	(	QString(loPropertyName[j].c_str()),
																		QString(loAlias[j].c_str()),
																		QString(loType[j].c_str()),
																		QString(loExtra[j].c_str()),
																		QString(loReference[j].c_str())));										
				
			}
			meDatabaseColumnsByClassName.push_back(meDatabaseColumns);
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		}
		
		return true;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::loadClasses -> " + QString(e.what()));
		return false;
    }		
}
/*********************************************************************
* Object calls
**********************************************************************/
clObjectCall* clClassLoader::callObjectDLL(QString paCurrentMethodSourceFile, int paLibNumber)
{	
	try
	{
		
		
		////////////////////////Loading the library///////////////////////////////////////////////////////////////////
		string loLibraryName = string(paCurrentMethodSourceFile.toStdString());
		
		
		
		
		
		meLibraryLib[paLibNumber] = dlopen(loLibraryName.c_str(), RTLD_LAZY);
		
		if (meLibraryLib[paLibNumber] == NULL) {
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callObjectDLL -> Library [" + paCurrentMethodSourceFile + "] not found");
			return NULL;
		}
		else
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callObjectDLL -> Library [" + paCurrentMethodSourceFile + "] found");
			
			
			
			//Getting the class
			CreateModuleObjectFn * (*create)();
			void (*destroy)(CreateModuleObjectFn*);
			
			create = (CreateModuleObjectFn* (*)())dlsym(meLibraryLib[paLibNumber], "create_object");
			destroy = (void (*)(CreateModuleObjectFn*))dlsym(meLibraryLib[paLibNumber], "destroy_object");
			
			meCreateModuleObjectFn[paLibNumber] = (CreateModuleObjectFn*)create();
			
			
			//meCreateModuleObjectFn[paLibNumber] = (CreateModuleObjectFn)GetProcAddress(meLibraryLib[paLibNumber], "CreateModuleObject");
			clObjectCall *loObjectCall;
			loObjectCall=(*meCreateModuleObjectFn[paLibNumber])();
			if (!loObjectCall)
			{
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callObjectDLL -> Loading library failed [" + paCurrentMethodSourceFile + "]");
				return NULL;
			}
			else
			{ 
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callObjectDLL -> Loading library succes [" + paCurrentMethodSourceFile + "]");
				loObjectCall->ClassName = QString(meClassNames.at(paLibNumber).toUpper());
				return (*meCreateModuleObjectFn[paLibNumber])();
			}
		}
		return NULL;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callObjectDLL() -> " + QString(e.what()));
		return NULL;
    }
}
bool clClassLoader::cleanObjectDLL(int paLibNumber)
{
	try
	{
		////////////////////////////////////////////////////////// Free the library handle /////////////////////////////////////////////////////////////////////////
	   if (meCreateModuleObjectFn[paLibNumber] != NULL) 
	   {  
		   /*
			if(FreeLibrary(meLibraryLib[paLibNumber]))
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callRoutineDLL() -> Unloading library succes ...");
			else
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::callRoutineDLL() -> Unloading library failed ...");
			*/
	   }
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::cleanObjectDLL() -> " + QString(e.what()));
		return NULL;
    }
}
clObject clClassLoader::getObject(QString meClassName)
{
	clObject loObject(meIceClientServer, meIceClientLogging);
	try
	{
		////////////////////////////////////////////////////////// Free the library handle /////////////////////////////////////////////////////////////////////////
		for (int i = 0; i < (int) meClassNames.size(); i++)
		{
			if (meClassDllNames.at(i).toUpper().compare(meClassName.toUpper()) == 0)
			{
				loObject.meObject = (*meCreateModuleObjectFn[i])();
				loObject.ClassName = meClassName.toUpper();
				loObject.meObjectCallList = meObjectCall;
				loObject.meClassNameList = meClassNames;
				loObject.meDatabaseColumnsByClassNameList = meDatabaseColumnsByClassName;

				return loObject;
			}
		}
		return loObject;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clClassLoader::getObject() -> " + QString(e.what()));
		return loObject;
    }	
}
