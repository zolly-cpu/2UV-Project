#ifndef CLCLASSLOADER_H
#define CLCLASSLOADER_H

#include <vector>
#include <iostream>
#include <string>
#include <dlfcn.h>

#ifdef WIN32
#include <windows.h>
#elif defined(_WIN32)
#include <windows.h>
#elif defined(__WIN32)
#include <windows.h>
#elif defined(__WIN32__)
#include <windows.h>
#else

#endif

#include <QtCore/QString>
#include <QtCore/QObject>
#include <QtCore/QFile>

#include <QtXml/QDomDocument>
#include <QtXml/QDomNode>
#include <QtXml/QDomElement>
#include <QtNetwork/QHostInfo>

#include "clDatabaseColumn.h"
#include "clIceClientLogging.h"
#include "clIceClientServer.h"
#include "clObjectCall.h"
#include "clObjectCallHeader.h"
#include "clObject.h"

//! [0]
class clClassLoader : public QObject
{
	Q_OBJECT	
public:
    clClassLoader(clIceClientServer * paIceClientServer, clIceClientLogging *paIceClientLogging);
    ~clClassLoader();
public slots:
    
signals:
    
private:
	bool initializeLibrarys();
	bool readClassesFromXmlFile();
	bool loadClasses();
	
	clObjectCall* callObjectDLL(QString paCurrentMethodSourceFile, int paLibNumber);
	bool cleanObjectDLL(int paLibNumber);

	clIceClientLogging * meIceClientLogging;
	clIceClientServer * meIceClientServer;	
	
	vector <QString> meClassNames;
	vector <QString> meClassDllNames;
	vector <vector<QString>> meClassMethods;
	vector<vector<clDatabaseColumn *>> meDatabaseColumnsByClassName;
	vector <QString> meClassPaths;
	
	
	void* meLibraryLib[1000];
	//HMODULE meLibraryLib[1000];
	CreateModuleObjectFn* meCreateModuleObjectFn[1000];	
public:	
	vector <clObjectCall *> meObjectCall;
	clObject getObject(QString meClassName);
	
};
//! [0]

#endif
