/********************************************************************************
** Form generated from reading UI file 'wdObjectLocator.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDOBJECTLOCATOR_H
#define WDOBJECTLOCATOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdObjectLocator
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QTreeWidget *tvwLocationView;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *btnRefresh;

    void setupUi(QWidget *wdObjectLocator)
    {
        if (wdObjectLocator->objectName().isEmpty())
            wdObjectLocator->setObjectName(QString::fromUtf8("wdObjectLocator"));
        wdObjectLocator->resize(882, 628);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(100);
        sizePolicy.setVerticalStretch(100);
        sizePolicy.setHeightForWidth(wdObjectLocator->sizePolicy().hasHeightForWidth());
        wdObjectLocator->setSizePolicy(sizePolicy);
        wdObjectLocator->setMaximumSize(QSize(16777215, 16777215));
        verticalLayout = new QVBoxLayout(wdObjectLocator);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMaximumSize);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetMaximumSize);
        tvwLocationView = new QTreeWidget(wdObjectLocator);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        tvwLocationView->setHeaderItem(__qtreewidgetitem);
        tvwLocationView->setObjectName(QString::fromUtf8("tvwLocationView"));

        horizontalLayout->addWidget(tvwLocationView);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetMaximumSize);
        btnRefresh = new QPushButton(wdObjectLocator);
        btnRefresh->setObjectName(QString::fromUtf8("btnRefresh"));

        horizontalLayout_3->addWidget(btnRefresh);


        verticalLayout->addLayout(horizontalLayout_3);


        retranslateUi(wdObjectLocator);

        QMetaObject::connectSlotsByName(wdObjectLocator);
    } // setupUi

    void retranslateUi(QWidget *wdObjectLocator)
    {
        wdObjectLocator->setWindowTitle(QCoreApplication::translate("wdObjectLocator", "wdObjectView", nullptr));
        btnRefresh->setText(QCoreApplication::translate("wdObjectLocator", "Refresh", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdObjectLocator: public Ui_wdObjectLocator {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDOBJECTLOCATOR_H
