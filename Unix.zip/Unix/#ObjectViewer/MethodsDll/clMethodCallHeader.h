#pragma once
#include <QtCore/QString>
#include "clMethodCall.h"

typedef clMethodCall *(*CreateModuleFn)();
