/********************************************************************************
** Form generated from reading UI file 'wdCycleBuilderView.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDCYCLEBUILDERVIEW_H
#define WDCYCLEBUILDERVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdCycleBuilderView
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QTreeWidget *trwCycles;
    QTreeWidget *trwRoutines;
    QTreeWidget *trwRoutineCycles;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *btnRefresh;
    QPushButton *btnCreateRoutineCycle;
    QPushButton *btnSaveCycle;
    QPushButton *btnRefreshCycle;

    void setupUi(QWidget *wdCycleBuilderView)
    {
        if (wdCycleBuilderView->objectName().isEmpty())
            wdCycleBuilderView->setObjectName(QString::fromUtf8("wdCycleBuilderView"));
        wdCycleBuilderView->resize(882, 628);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(100);
        sizePolicy.setVerticalStretch(100);
        sizePolicy.setHeightForWidth(wdCycleBuilderView->sizePolicy().hasHeightForWidth());
        wdCycleBuilderView->setSizePolicy(sizePolicy);
        wdCycleBuilderView->setMaximumSize(QSize(16777215, 16777215));
        verticalLayout = new QVBoxLayout(wdCycleBuilderView);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetMaximumSize);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        trwCycles = new QTreeWidget(wdCycleBuilderView);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        trwCycles->setHeaderItem(__qtreewidgetitem);
        trwCycles->setObjectName(QString::fromUtf8("trwCycles"));

        verticalLayout_2->addWidget(trwCycles);

        trwRoutines = new QTreeWidget(wdCycleBuilderView);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem();
        __qtreewidgetitem1->setText(0, QString::fromUtf8("1"));
        trwRoutines->setHeaderItem(__qtreewidgetitem1);
        trwRoutines->setObjectName(QString::fromUtf8("trwRoutines"));

        verticalLayout_2->addWidget(trwRoutines);

        trwRoutineCycles = new QTreeWidget(wdCycleBuilderView);
        QTreeWidgetItem *__qtreewidgetitem2 = new QTreeWidgetItem();
        __qtreewidgetitem2->setText(0, QString::fromUtf8("1"));
        trwRoutineCycles->setHeaderItem(__qtreewidgetitem2);
        trwRoutineCycles->setObjectName(QString::fromUtf8("trwRoutineCycles"));
        trwRoutineCycles->setDragDropOverwriteMode(false);
        trwRoutineCycles->setDragDropMode(QAbstractItemView::DragOnly);

        verticalLayout_2->addWidget(trwRoutineCycles);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        btnRefresh = new QPushButton(wdCycleBuilderView);
        btnRefresh->setObjectName(QString::fromUtf8("btnRefresh"));

        horizontalLayout_2->addWidget(btnRefresh);

        btnCreateRoutineCycle = new QPushButton(wdCycleBuilderView);
        btnCreateRoutineCycle->setObjectName(QString::fromUtf8("btnCreateRoutineCycle"));

        horizontalLayout_2->addWidget(btnCreateRoutineCycle);

        btnSaveCycle = new QPushButton(wdCycleBuilderView);
        btnSaveCycle->setObjectName(QString::fromUtf8("btnSaveCycle"));

        horizontalLayout_2->addWidget(btnSaveCycle);

        btnRefreshCycle = new QPushButton(wdCycleBuilderView);
        btnRefreshCycle->setObjectName(QString::fromUtf8("btnRefreshCycle"));

        horizontalLayout_2->addWidget(btnRefreshCycle);


        verticalLayout_2->addLayout(horizontalLayout_2);


        horizontalLayout->addLayout(verticalLayout_2);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(wdCycleBuilderView);

        QMetaObject::connectSlotsByName(wdCycleBuilderView);
    } // setupUi

    void retranslateUi(QWidget *wdCycleBuilderView)
    {
        wdCycleBuilderView->setWindowTitle(QCoreApplication::translate("wdCycleBuilderView", "wdParameterView", nullptr));
        btnRefresh->setText(QCoreApplication::translate("wdCycleBuilderView", "Refresh", nullptr));
        btnCreateRoutineCycle->setText(QCoreApplication::translate("wdCycleBuilderView", "Create Routine-Cycle", nullptr));
        btnSaveCycle->setText(QCoreApplication::translate("wdCycleBuilderView", "Save Cycle", nullptr));
        btnRefreshCycle->setText(QCoreApplication::translate("wdCycleBuilderView", "Refresh Cycle View", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdCycleBuilderView: public Ui_wdCycleBuilderView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDCYCLEBUILDERVIEW_H
