/********************************************************************************
** Form generated from reading UI file 'wdClientLogger.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDCLIENTLOGGER_H
#define WDCLIENTLOGGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdClientLogger
{
public:
    QPushButton *btnPing;
    QPushButton *btnShutdown;
    QPushButton *btnSendMessage;
    QLineEdit *txtMessage;
    QLineEdit *txtLogNumber;
    QLabel *lblMessage;
    QLabel *label;
    QLabel *lblComputerName;
    QLineEdit *txtComputerName;

    void setupUi(QWidget *wdClientLogger)
    {
        if (wdClientLogger->objectName().isEmpty())
            wdClientLogger->setObjectName(QString::fromUtf8("wdClientLogger"));
        wdClientLogger->resize(391, 211);
        btnPing = new QPushButton(wdClientLogger);
        btnPing->setObjectName(QString::fromUtf8("btnPing"));
        btnPing->setGeometry(QRect(10, 10, 91, 23));
        btnShutdown = new QPushButton(wdClientLogger);
        btnShutdown->setObjectName(QString::fromUtf8("btnShutdown"));
        btnShutdown->setGeometry(QRect(10, 40, 91, 23));
        btnSendMessage = new QPushButton(wdClientLogger);
        btnSendMessage->setObjectName(QString::fromUtf8("btnSendMessage"));
        btnSendMessage->setGeometry(QRect(10, 70, 91, 23));
        txtMessage = new QLineEdit(wdClientLogger);
        txtMessage->setObjectName(QString::fromUtf8("txtMessage"));
        txtMessage->setGeometry(QRect(90, 170, 291, 20));
        txtLogNumber = new QLineEdit(wdClientLogger);
        txtLogNumber->setObjectName(QString::fromUtf8("txtLogNumber"));
        txtLogNumber->setGeometry(QRect(90, 110, 113, 20));
        lblMessage = new QLabel(wdClientLogger);
        lblMessage->setObjectName(QString::fromUtf8("lblMessage"));
        lblMessage->setGeometry(QRect(10, 170, 51, 16));
        label = new QLabel(wdClientLogger);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 110, 61, 16));
        lblComputerName = new QLabel(wdClientLogger);
        lblComputerName->setObjectName(QString::fromUtf8("lblComputerName"));
        lblComputerName->setGeometry(QRect(10, 140, 81, 16));
        txtComputerName = new QLineEdit(wdClientLogger);
        txtComputerName->setObjectName(QString::fromUtf8("txtComputerName"));
        txtComputerName->setGeometry(QRect(90, 140, 181, 20));

        retranslateUi(wdClientLogger);

        QMetaObject::connectSlotsByName(wdClientLogger);
    } // setupUi

    void retranslateUi(QWidget *wdClientLogger)
    {
        wdClientLogger->setWindowTitle(QCoreApplication::translate("wdClientLogger", "Form", nullptr));
        btnPing->setText(QCoreApplication::translate("wdClientLogger", "Ping", nullptr));
        btnShutdown->setText(QCoreApplication::translate("wdClientLogger", "Shutdown", nullptr));
        btnSendMessage->setText(QCoreApplication::translate("wdClientLogger", "Send message", nullptr));
        lblMessage->setText(QCoreApplication::translate("wdClientLogger", "Message:", nullptr));
        label->setText(QCoreApplication::translate("wdClientLogger", "LogNumber:", nullptr));
        lblComputerName->setText(QCoreApplication::translate("wdClientLogger", "ComputerName:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdClientLogger: public Ui_wdClientLogger {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDCLIENTLOGGER_H
