#define INFO_BUFFER_SIZE 32767
#include "clObject.h"

clObject::clObject(clIceClientServer * paIceClientServer, clIceClientLogging *paIceClientLogging)
{
	try
	{
		meIceClientLogging = paIceClientLogging;
		meIceClientServer = paIceClientServer;
		meObject = NULL;
	}
	catch(...)
	{
		cout << "clWorkstationCycles::clWorkstationCycles -> failed" << endl;
	}
}
clObject::~clObject()
{
}
bool clObject::get(QString paPropName, QString &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QString &paValue) -> Classname or id is empty ...");
			return false;
		}
		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QString &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QString &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QString &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue = QString(loReturnValues.at(0).c_str());
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QString &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, vector <QString> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QString> &paValue) -> Classname or id is empty ...");
			return false;
		}
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QString> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QString> &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QString> &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue.clear();
		QString loValues = QString(loReturnValues.at(0).c_str());
		loValues = loValues.replace("{","").replace("}","");
		if (loValues.compare(QString("")) != 0)
		{
			QStringList loStringList = loValues.split(",");
			for (int i = 0; i < loStringList.size(); i++)
			{
					paValue.push_back(loStringList.at(i));
			}
		}
		return true;				
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QString> &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, QDateTime &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QDateTime &paValue) -> Classname or id is empty ...");
			return false;
		}	
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QDateTime &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QDateTime &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QDateTime &paValue) -> no values to return ...");
			return false;					
		}
		
		QDateTime loDateTime;
		loDateTime.fromString(loReturnValues.at(0).c_str(), "yyyy-MM-dd hh:mm:ss.zzz");
		paValue = loDateTime;
		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, QDateTime &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, vector <QDateTime> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QDateTime> &paValue) -> Classname or id is empty ...");
			return false;
		}	
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QDateTime> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QDateTime> &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QDateTime> &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue.clear();
		QString loValues = QString(loReturnValues.at(0).c_str());
		loValues = loValues.replace("{","").replace("}","");
		if (loValues.compare(QString("")) != 0)
		{
			QStringList loStringList = loValues.split(",");
			for (int i = 0; i < loStringList.size(); i++)
			{
				QDateTime loDateTime;
				loDateTime.fromString(loStringList.at(i), "yyyy-MM-dd hh:mm:ss.zzz");
				paValue.push_back(loDateTime);
			}
		}		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <QDateTime> &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, float &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, float &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, float &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, float &paValue) -> " + loReturnMessage);			
		
		if ((int) loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, float &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue = QString(loReturnValues.at(0).c_str()).toFloat();
		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, float &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, vector <float> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <float> &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		
		QString loClass = ClassName.toUpper();
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <float> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <float> &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <float> &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue.clear();
		QString loValues = QString(loReturnValues.at(0).c_str());
		loValues = loValues.replace("{","").replace("}","");
		if (loValues.compare(QString("")) != 0)
		{
			QStringList loStringList = loValues.split(",");
			for (int i = 0; i < loStringList.size(); i++)
			{
				paValue.push_back(loStringList.at(i).toFloat());
			}
		}		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <float> &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, int &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, int &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, int &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, int &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, int &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue = QString(loReturnValues.at(0).c_str()).toInt();
		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, int &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, vector <int> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <int> &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		
		QString loClass = ClassName.toUpper();
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <int> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <int> &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <int> &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue.clear();
		QString loValues = QString(loReturnValues.at(0).c_str());
		loValues = loValues.replace("{","").replace("}","");
		if (loValues.compare(QString("")) != 0)
		{
			QStringList loStringList = loValues.split(",");
			for (int i = 0; i < loStringList.size(); i++)
			{
				paValue.push_back(loStringList.at(i).toInt());
			}
		}		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <int> &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, double &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, double &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		QString loClass = ClassName.toUpper();
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, double &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, double &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, double &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue = QString(loReturnValues.at(0).c_str()).toDouble();
		
		return true;			
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, double &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, vector <double> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <double> &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		
		QString loClass = ClassName.toUpper();
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <double> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <double> &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <double> &paValue) -> no values to return ...");
			return false;					
		}
		
		paValue.clear();
		QString loValues = QString(loReturnValues.at(0).c_str());
		loValues = loValues.replace("{","").replace("}","");
		if (loValues.compare(QString("")) != 0)
		{
			QStringList loStringList = loValues.split(",");
			for (int i = 0; i < (int) loStringList.size(); i++)
			{
				paValue.push_back(loStringList.at(i).toDouble());
			}
		}		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <double> &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, clObject &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		QString loClass = ClassName.toUpper();
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> no values to return ...");
			return false;					
		}
		
		//Check the references
		vector <QString> loReferences = getReferencesFromTableInformation(ClassName.toUpper(),paPropName.toUpper());
		
		
		/*****************************************
		* Check if object exists
		*******************************************/
		vector <std::string> loPropertiesCheck;
		vector <std::string> loReturnValuesCheck;
		QString loReturnMessageCheck;

		loProperties.push_back("NAME");
		
		for (int i = 0; i < (int) loReferences.size(); i++)
		{	
			loReturnValuesCheck.clear();
			loReturnMessageCheck = QString("");
			
			
			QString loClass = loReferences.at(i).toUpper();
			QString loUUID = QString(loReturnValues.at(0).c_str());
			
			
			if (!meIceClientServer->getFromTableDatabaseById(loClass,loUUID,loPropertiesCheck,loReturnValuesCheck,loReturnMessageCheck))
			{
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> " + loReturnMessageCheck);
			}
			
			if (loReturnValuesCheck.size() < 1)
			{
				meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> no values to return ...");		
			}
			else
			{
				//Create object for this class
				createObject(loReferences.at(i).toUpper(),QString(loReturnValues.at(0).c_str()), paValue);
				return true;			
			}
		}
		return false;			
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, clObject &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::get(QString paPropName, vector <clObject> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, vector <clObject> &paValue) -> Classname or id is empty ...");
			return false;
		}		
		/*****************************************
		* Getting the PROP from table
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loReturnValues;
		QString loReturnMessage;

		loProperties.push_back(paPropName.toUpper().toStdString());
		
		
		QString loClass = ClassName.toUpper();
		
		
		
		if (!meIceClientServer->getFromTableDatabaseById(loClass,ObjectId,loProperties,loReturnValues,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, <clObject> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, <clObject> &paValue) -> " + loReturnMessage);			
		
		if (loReturnValues.size() < 1)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, <clObject> &paValue) -> no values to return ...");
			return false;					
		}
		
		QString loReturnString = QString(loReturnValues.at(0).c_str());
		loReturnString = loReturnString.replace("{","").replace("}","");
		if (loReturnString.compare(QString("")))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, <clObject> &paValue) -> no values to return ...");
			return true;
		}
		
		QStringList loReturnStringSplit = loReturnString.split(",");
		
		//Check the references
		vector <QString> loReferences = getReferencesFromTableInformation(ClassName.toUpper(),paPropName.toUpper());
		
		/*****************************************
		* Check if object exists
		*******************************************/
		vector <std::string> loPropertiesCheck;
		vector <std::string> loReturnValuesCheck;
		QString loReturnMessageCheck;

		loProperties.push_back("NAME");
		
		for (int k = 0; k < loReturnStringSplit.size(); k++)
		{
			
				for (int i = 0; i < (int) loReferences.size(); i++)
				{	
					loReturnValuesCheck.clear();
					loReturnMessageCheck = QString("");
					
					
					QString loClass = loReferences.at(i).toUpper();
					QString loUUID = QString(loReturnStringSplit.at(k));
					
					if (!meIceClientServer->getFromTableDatabaseById(loClass,loUUID,loPropertiesCheck,loReturnValuesCheck,loReturnMessageCheck))
					{
						meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, <clObject> &paValue) -> " + loReturnMessageCheck);
					}
					if (loReturnValuesCheck.size() < 1)
					{
						meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get(QString paPropName, <clObject> &paValue) -> no values to return ...");		
					}
					else
					{
						//Create object for this class
						clObject loObject(meIceClientServer, meIceClientLogging);
						createObject(loReferences.at(i).toUpper(),loReturnStringSplit.at(k), loObject);
						paValue.push_back(loObject);
						break;
					}
				}
		}
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::get -> " + QString(e.what()));
		return false;
    }
}
bool clObject::getParents(QString paTableName, QString paPropName, vector <clObject> &paValue)
{
	try
	{
		//TODO WVA
		
		
		
		
		/*****************************************
		* Get the table info
		*******************************************/
		 vector<std::string> loPropertyName;
		 vector<std::string> loAlias;
		 vector<std::string> loType;
		 vector<std::string> loExtra;
		 vector<std::string> loReference;
		 QString loReturnMessageObject;


		 if(!meIceClientServer->getAllPropertiesFromTable(  paTableName,
														loPropertyName,
														loAlias,
														loType,
														loExtra,
														loReference,
														loReturnMessageObject))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getParents -> " + loReturnMessageObject);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getParents -> " + loReturnMessageObject);
		
		
		int loKind = 0;
		for(int i = 0; i < (int) loPropertyName.size(); i++)
		{
			if(QString(loPropertyName.at(i).c_str()).toUpper().compare(paPropName.toUpper()) == 0)
			{
				if (QString(loType.at(i).c_str()).toUpper().compare(QString("UUID")) == 0)
				{
					QStringList loStringList = QString(loReference.at(i).c_str()).split("$;$");
					for (int j = 0; j < (int) loStringList.size(); j++)
					{
						if (loStringList.at(j).toUpper().compare(ClassName.toUpper()))
						{
							loKind = 1;
							break;
						}
					}
				}
				else if (QString(loType.at(i).c_str()).toUpper().compare(QString("UUID[]")) == 0)
				{
					QStringList loStringList = QString(loReference.at(i).c_str()).split("$;$");
					for (int j = 0; j < (int) loStringList.size(); j++)
					{
						if (loStringList.at(j).toUpper().compare(ClassName.toUpper()))
						{
							//Get the objects
							loKind = 2;
							break;
						}
					}					
				}
			}			
		}
		
		//Property not found or not for this class
		if (loKind == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getParents -> Wrong property, no parent with this property is supporting this class ...");
			return false;
		}
		
		/*****************************************
		* Get the id's of the objects containing this id
		*******************************************/
		vector <std::string> loProperties;
		vector <std::string> loValues;
		vector <std::string> loTypeValues;
		vector <std::string> loLogExp;
		vector <std::string> loReturnIds;
		QString loReturnMessage;
		
		loProperties.push_back(paPropName.toStdString());
		loValues.push_back(ObjectId.toStdString());
		if (loKind == 2)
		{					
			loTypeValues.push_back(QString("uuid[]").toStdString());
			loLogExp.push_back(QString("= ANY").toStdString());			
		}
		if (loKind == 1)
		{			
			loTypeValues.push_back(QString("uuid").toStdString());
			loLogExp.push_back(QString("=").toStdString());
		}
		
		
		QString loStop = QString("0");
		QString loStart = QString("0");
		
		
		
		
		
		if (!meIceClientServer->getFromTableDatbaseByProperty(paTableName,loStop,loStart,loProperties,loValues,loTypeValues,loLogExp,loReturnIds,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getParents() -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getParents() -> " + loReturnMessage);
		
		for (int k = 0; k < (int) loReturnIds.size(); k++)
		{
			//Create object for this class
			clObject loObject(meIceClientServer, meIceClientLogging);
			createObject(paTableName.toUpper(),QString(loReturnIds.at(k).c_str()), loObject);
			paValue.push_back(loObject);
		}
		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getParents -> " + QString(e.what()));
		return false;
    }
}		
bool clObject::set(QString paPropName, QString paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QString paValue) -> Classname or id is empty ...");
			return false;
		}	
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QString paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		
		vector<std::string> loColumns;
		vector<std::string> loValue;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValue.push_back(paValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValue,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QString paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QString paValue) -> " + loReturnMessage);

		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QString paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, vector <QString> paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QString> paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QString> paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		//Create array string
		QString loValue = QString("");
		for (int i = 0; i < (int) paValue.size(); i++)
		{
			if (loValue.compare(QString("")) == 0)
			{
				loValue = loValue + paValue.at(i);
			}
			else
			{
				loValue = loValue + QString("$;$") + paValue.at(i);
			}
		}
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(loValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QString> paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QString> paValue) -> " + loReturnMessage);

		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QString> paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, QDateTime paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QDateTime paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QDateTime paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(QString(paValue.toString("yyyy-MM-dd HH:mm:ss.zzz")).toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QDateTime paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QDateTime paValue) -> " + loReturnMessage);

		return true;	
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, QDateTime paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, vector <QDateTime> paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QDateTime> paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QDateTime> paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		//Create array string
		QString loValue = QString("");
		for (int i = 0; i < (int) paValue.size(); i++)
		{
			if (loValue.compare(QString("")) == 0)
			{
				loValue = loValue + QString(paValue.at(i).toString("yyyy-MM-dd HH:mm:ss.zzz"));
			}
			else
			{
				loValue = loValue + QString("$;$") + QString(paValue.at(i).toString("yyyy-MM-dd HH:mm:ss.zzz"));
			}
		}
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(loValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QDateTime> paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QDateTime> paValue) -> " + loReturnMessage);

		return true;	
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <QDateTime> paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, float paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, float paValue) -> Classname or id is empty ...");
			return false;
		}	
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, float paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		
		vector<std::string> loColumns;
		vector<std::string> loValue;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValue.push_back(QString::number(paValue).toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValue,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, float paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, float paValue) -> " + loReturnMessage);

		return true;				
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, float paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, vector <float> paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <float> paValue) -> Classname or id is empty ...");
			return false;
		}		
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <float> paValue) -> Could not get type for propertie ...");
			return false;
		}
		//Create array string
		QString loValue = QString("");
		for (int i = 0; i < (int) paValue.size(); i++)
		{
			if (loValue.compare(QString("")) == 0)
			{
				loValue = loValue + QString::number(paValue.at(i));
			}
			else
			{
				loValue = loValue + QString("$;$") + QString::number(paValue.at(i));
			}
		}
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(loValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <float> paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <float> paValue) -> " + loReturnMessage);

		return true;	
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <float> paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, int paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, int paValue) -> Classname or id is empty ...");
			return false;
		}	
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, int paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		
		vector<std::string> loColumns;
		vector<std::string> loValue;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValue.push_back(QString::number(paValue).toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValue,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, int paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, int paValue) -> " + loReturnMessage);

		return true;				
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, int paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, vector <int> paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <int> paValue) -> Classname or id is empty ...");
			return false;
		}		
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <int> paValue) -> Could not get type for propertie ...");
			return false;
		}
		//Create array string
		QString loValue = QString("");
		for (int i = 0; i < (int) paValue.size(); i++)
		{
			if (loValue.compare(QString("")) == 0)
			{
				loValue = loValue + QString::number(paValue.at(i));
			}
			else
			{
				loValue = loValue + QString("$;$") + QString::number(paValue.at(i));
			}
		}
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(loValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <int> paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <int> paValue) -> " + loReturnMessage);

		return true;	
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <int> paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, double paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, double paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, double paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		
		vector<std::string> loColumns;
		vector<std::string> loValue;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValue.push_back(QString::number(paValue).toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValue,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, double paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, double paValue) -> " + loReturnMessage);

		return true;			
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, double paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, vector <double> paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <double> paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <double> paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		//Create array string
		QString loValue = QString("");
		for (int i = 0; i < (int) paValue.size(); i++)
		{
			if (loValue.compare(QString("")) == 0)
			{
				loValue = loValue + QString::number(paValue.at(i));
			}
			else
			{
				loValue = loValue + QString("$;$") + QString::number(paValue.at(i));
			}
		}
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(loValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <double> paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <double> paValue) -> " + loReturnMessage);

		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <double> paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, clObject &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, clObject &paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, clObject &paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		
		vector<std::string> loColumns;
		vector<std::string> loValue;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValue.push_back(paValue.ObjectId.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValue,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, clObject &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, clObject &paValue) -> " + loReturnMessage);

		return true;	
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, clObject &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::set(QString paPropName, vector <clObject> &paValue)
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> &paValue) -> Classname or id is empty ...");
			return false;
		}				
		//Getting the property type
		QString loPropType;		
		if (!getTypeFromTableInformation(ClassName.toUpper(),paPropName, loPropType))
		{ 
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> &paValue) -> Could not get type for propertie ...");
			return false;
		}
		
		//Create array string
		QString loValue = QString("");
		for (int i = 0; i < (int) paValue.size(); i++)
		{
			if (loValue.compare(QString("")) == 0)
			{
				loValue = loValue + paValue.at(i).ObjectId;
			}
			else
			{
				loValue = loValue + QString("$;$") + paValue.at(i).ObjectId;
			}
		}
		
		vector<std::string> loColumns;
		vector<std::string> loValues;
		vector<std::string> loTypeValue;
		QString loReturnMessage;
		
		loColumns.push_back(paPropName.toUpper().toStdString());
		loValues.push_back(loValue.toStdString());
		loTypeValue.push_back(loPropType.toStdString());


		if (!meIceClientServer->updateIntoTableDatabase(	ClassName,
															ObjectId,
															loColumns,
															loValues,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> &paValue) -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> &paValue) -> " + loReturnMessage);

		return true;			
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> &paValue) -> " + QString(e.what()));
		return false;
    }
}
bool clObject::deleteObject()
{
	try
	{
		if(ObjectId.compare(QString("")) == 0 || ClassName.compare(QString("")) == 0)
		{
			meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::deleteObject() -> Classname or id is empty ...");
			return false;
		}

		QString loReturnMessage;
		
		QString loClassName = ClassName.toUpper();
		QString loObjectId = ObjectId.toUpper();
		
		meIceClientServer->deleteIntoTableDatabase(loClassName,loObjectId,loReturnMessage);
		meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::deleteObject() -> ..." + loReturnMessage);
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> paValue) -> " + QString(e.what()));
		return false;
    }
}	
bool clObject::insertObject()
{
	try
	{
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::set(QString paPropName, vector <clObject> paValue) -> " + QString(e.what()));
		return false;
    }
}	
	//???//
bool clObject::queryObjects(vector <QString> paProperties, vector <QString> paValue, vector <QString> paValueType, vector <QString> paLogExp, vector <clObject> &paObjects)
{
	
	try
	{
		
		
		/*****************************************
		* Getting the CYCLE_ROUTINE objects for this cycle
		*******************************************/
		/*
		QString loTableName("CYCLE_ROUTINE");
		vector <std::string> loProperties;
		vector <std::string> loValues;
		vector <std::string> loTypeValues;
		vector <std::string> loLogExp;
		vector <std::string> loReturnIds;
		QString loReturnMessage;
		
		loProperties.push_back(QString("CYCLE").toStdString());
		loValues.push_back(meObjectId.toStdString());
		loTypeValues.push_back(QString("uuid").toStdString());
		loLogExp.push_back(QString("=").toStdString());
		
		if (!meIceClientServer->getFromTableDatbaseByProperty(loTableName,QString("0"),QString("0"),loProperties,loValues,loTypeValues,loLogExp,loReturnIds,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clWorkstationCycles::getWorkstationCycles() -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clWorkstationCycles::getWorkstationCycles() -> " + loReturnMessage);				
		
		*/
		
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::queryObjects -> " + QString(e.what()));
		return false;
    }
}
bool clObject::queryAll(int paIndexFrom,int paIndexTo, vector <clObject> &paObjects)
{
	try
	{
		return true;		
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::queryAll -> " + QString(e.what()));
		return false;
    }
}

vector<QString> clObject::getReferencesFromTableInformation(QString paClassName,QString paPropertyName)
{

	
	vector<QString> loRef;
	try
	{
		for (int i = 0; i < (int) meClassNameList.size(); i++)
		{
			if (meClassNameList.at(i).toUpper().compare(paClassName.toUpper()) == 0)
			{
				vector <clDatabaseColumn *> loDatabaseColumns = meDatabaseColumnsByClassNameList.at(i);
				for (int j = 0; j < (int) loDatabaseColumns.size(); j++)
				{
					if (loDatabaseColumns.at(j)->getName().toUpper().compare(paPropertyName.toUpper()) == 0)
					{
						QString loReferences = loDatabaseColumns.at(j)->getReference();
						QStringList loStringList = loReferences.split("$;$");
						for (int k = 0; k < (int) loStringList.size(); k++)
						{
							loRef.push_back(loStringList.at(k));
						}
						return loRef;
					}
				}
			}
		}
		return loRef;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getReferencesFromTableInformation -> " + QString(e.what()));
		return loRef;
    }
}
bool clObject::getTypeFromTableInformation(QString paClassName,QString paPropertyName, QString &paPropertyType)
{

	
	vector<QString> loRef;
	try
	{
		for (int i = 0; i < (int) meClassNameList.size(); i++)
		{
			if (meClassNameList.at(i).toUpper().compare(paClassName.toUpper()) == 0)
			{
				vector <clDatabaseColumn *> loDatabaseColumns = meDatabaseColumnsByClassNameList.at(i);
				for (int j = 0; j < (int) loDatabaseColumns.size(); j++)
				{
					if (loDatabaseColumns.at(j)->getName().toUpper().compare(paPropertyName.toUpper()) == 0)
					{
						paPropertyType = loDatabaseColumns.at(j)->getType();
						return true;
					}
				}
			}
		}
		return false;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::getTypeFromTableInformation -> " + QString(e.what()));
		return false;
    }
}

bool clObject::createObject(QString paClassName, QString paObjectId, clObject &paObject)
{

	
	try
	{
		//Get the right library
		for (int i = 0; i < (int) meClassNameList.size(); i++)
		{
			if (meClassNameList.at(i).toUpper().compare(paClassName.toUpper())==0)
			{
				paObject.meObject = meObjectCallList.at(i);		
				break;
			}
		}
		//Fill the object
		paObject.ObjectId = paObjectId;
		paObject.ClassName = paClassName;
		paObject.meObjectCallList = meObjectCallList;
		paObject.meClassNameList = meClassNameList;
		paObject.meDatabaseColumnsByClassNameList = meDatabaseColumnsByClassNameList;
		return true;
	}
    catch(exception &e)
    {	
        meIceClientLogging->insertItem("10",QString(QHostInfo::localHostName()),"2UVServerTest.exe","clObject::createObject -> " + QString(e.what()));
		return false;
    }	
}
