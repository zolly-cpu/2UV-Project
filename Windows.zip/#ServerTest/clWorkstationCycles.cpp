#define INFO_BUFFER_SIZE 32767
#include "clWorkstationCycles.h"

clWorkstationCycles::clWorkstationCycles(clIceClientServer * paIceClientServer, clIceClientLogging *paIceClientLogging)
{
	try
	{
		meIceClientServer = paIceClientServer;
		meIceClientLogging = paIceClientLogging;
		
		//////// Getting the cycles for this machine /////////////////////
		getWorkstationCycles();
	}
	catch(...)
	{
		cout << "clWorkstationCycles::clWorkstationCycles -> failed" << endl;
	}
}

clWorkstationCycles::~clWorkstationCycles()
{
	/*
	PyEval_RestoreThread( tstate ) ; // nb: this also locks the GIL
	Py_Finalize() ;
	*/
	
	PyGILState_Ensure(); // PyEval_RestoreThread(tstate); seems to work just as well
	Py_Finalize();
	
	for (int i=0; i < 20; i++)
	{
	
	}
}
bool clWorkstationCycles::getWorkstationCycles()
{
	// Get and display the name of the computer.
	TCHAR infoBuf[INFO_BUFFER_SIZE];
	DWORD  bufCharCount = INFO_BUFFER_SIZE;
	GetComputerName(infoBuf,&bufCharCount);	
	
	try
	{
		////////////////////////////////////////// Getting the cycles ///////////////////////////////////////////////////////////////
		QString loTableName("cycles");
		vector <std::string> loProperties;
		vector <std::string> loValues;
		vector <std::string> loTypeValues;
		vector <std::string> loLogExp;
		vector <std::string> loReturnIds;
		QString loReturnMessage;
		
		loProperties.push_back(QString("WORKSTATION_NAME").toStdString());
		loValues.push_back(string(QString(infoBuf).toUtf8()));
		loTypeValues.push_back(QString("varchar(255)").toStdString());
		loLogExp.push_back(QString("=").toStdString());
		
		if (!meIceClientServer->getFromTableDatbaseByProperty(loTableName,QString("0"),QString("0"),loProperties,loValues,loTypeValues,loLogExp,loReturnIds,loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clWorkstationCycles::getWorkstationCycles() -> " + loReturnMessage);
			return false;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clWorkstationCycles::getWorkstationCycles() -> " + loReturnMessage);
				
		if (loReturnIds.size() < 1) return false;
		
		//Initialise the threads
		for(int i=0; i < 20; i++)
		{
			meWorkstationCycle[i] = NULL;
		}
		
		
		// initialize Python
		Py_Initialize() ;
		PyEval_InitThreads() ; // nb: creates and locks the GIL
		// NOTE: We save the current thread state, and restore it when we unload,
		// so that we can clean up properly.
		tstate = PyEval_SaveThread() ;
		
		//Set the threads
		for (int i = 0; i < loReturnIds.size(); i++)
		{
			//Starting the threads//
			meWorkstationCycle[i] = new clWorkstationCycle(meIceClientServer, meIceClientLogging, QString(loReturnIds.at(i).c_str()), &meLock, this);
			connect(meWorkstationCycle[i], &clWorkstationCycle::resultReady, this, &clWorkstationCycles::handleResults);
			//connect(meWorkstationCycle[i], &clWorkstationCycle::finished, meWorkstationCycle[i], &QObject::deleteLater);
			meWorkstationCycle[i]->start();
		}
		
		return true;
	}
	catch(...)
	{
		return false;
	}
}
void clWorkstationCycles::handleResults(const QString &)
{
	try
	{
		
	}
	catch(...)
	{
		
	}	
}


