#ifndef _CLOPENLINKEDDOC_H
#define _CLOPENLINKEDDOC_H

#include <QtWidgets/QApplication>
#include <QtGui/QImage>
#include <QtGui/QPixmap>
#include <QtGui/QDesktopServices>
#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QUrl>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QPushButton>

#include <vector>
#include <iostream>
#include <windows.h>
#include <string>

#include "clIceClientLogging.h"
#include "clIceClientServer.h"
#include "clSaveLinkedDocUI.h"
#include "clMethodCall.h"

using namespace std;

class clOpenLinkedDoc : public clMethodCall
{
public:
    clOpenLinkedDoc ();
    ~clOpenLinkedDoc ();

	//BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved){
		//if(fdwReason == DLL_PROCESS_ATTACH){
		//CreateThread(0, 0, (LPTHREAD_START_ROUTINE)ThreadProc, 0, 0, 0);

public:
	bool createPluginClass(clIceClientServer * paIceClientServer,clIceClientLogging  * paIceClientLogging) override;
	int GetReturnParameters() override;
	bool doMethod(const vector <QString> &paParametersType, const vector <QString> &paParameters) override;
private:
	vector <QString> meParametersType;
	vector <QString> meParameters;
	clIceClientLogging * meIceClientLogging;
	clIceClientServer * meIceClientServer;	
	clSaveLinkedDocUI *meSaveLinkedDocUI;
};
#endif
extern "C" __declspec (dllexport) clMethodCall* CreateModule()
{
    // call the constructor of the actual implementation
    clMethodCall * module = new clOpenLinkedDoc();
    // return the created function
    return module;
}