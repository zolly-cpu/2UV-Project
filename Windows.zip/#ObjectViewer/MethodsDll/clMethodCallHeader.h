#pragma once
#include <Windows.h>
#include <QtCore/QString>
#include "clMethodCall.h"

typedef clMethodCall *(*CreateModuleFn)();