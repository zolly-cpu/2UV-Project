--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: a_allergy; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_allergy (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_allergy OWNER TO poststress;

--
-- Name: a_batch; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_batch (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_batch OWNER TO poststress;

--
-- Name: a_customer; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_customer (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_customer OWNER TO poststress;

--
-- Name: a_cycle_routine; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_cycle_routine (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_cycle_routine OWNER TO poststress;

--
-- Name: a_cycles; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_cycles (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_cycles OWNER TO poststress;

--
-- Name: a_diet; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_diet (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_diet OWNER TO poststress;

--
-- Name: a_does_not_like; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_does_not_like (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_does_not_like OWNER TO poststress;

--
-- Name: a_empl_group; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_empl_group (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_empl_group OWNER TO poststress;

--
-- Name: a_employee; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_employee (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_employee OWNER TO poststress;

--
-- Name: a_errors_living_obj_mach; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_errors_living_obj_mach (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_errors_living_obj_mach OWNER TO poststress;

--
-- Name: a_food_bread; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_bread (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_bread OWNER TO poststress;

--
-- Name: a_food_breakfast; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_breakfast (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_breakfast OWNER TO poststress;

--
-- Name: a_food_butter; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_butter (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_butter OWNER TO poststress;

--
-- Name: a_food_charcuterie; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_charcuterie (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_charcuterie OWNER TO poststress;

--
-- Name: a_food_dessert; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_dessert (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_dessert OWNER TO poststress;

--
-- Name: a_food_dinner; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_dinner (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_dinner OWNER TO poststress;

--
-- Name: a_food_drink; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_drink (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_drink OWNER TO poststress;

--
-- Name: a_food_drinkserivce; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_drinkserivce (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_drinkserivce OWNER TO poststress;

--
-- Name: a_food_lunch; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_lunch (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_lunch OWNER TO poststress;

--
-- Name: a_food_place; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_place (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_place OWNER TO poststress;

--
-- Name: a_food_portion; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_portion (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_portion OWNER TO poststress;

--
-- Name: a_food_sugar; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_sugar (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_sugar OWNER TO poststress;

--
-- Name: a_food_texture; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_food_texture (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_food_texture OWNER TO poststress;

--
-- Name: a_linkeddoc; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_linkeddoc (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_linkeddoc OWNER TO poststress;

--
-- Name: a_living_obj_mach; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_living_obj_mach (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_living_obj_mach OWNER TO poststress;

--
-- Name: a_mach_group; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_mach_group (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_mach_group OWNER TO poststress;

--
-- Name: a_operation; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_operation (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_operation OWNER TO poststress;

--
-- Name: a_paper; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_paper (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_paper OWNER TO poststress;

--
-- Name: a_planning; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_planning (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_planning OWNER TO poststress;

--
-- Name: a_product; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_product (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_product OWNER TO poststress;

--
-- Name: a_rti_add_chef; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_rti_add_chef (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_rti_add_chef OWNER TO poststress;

--
-- Name: a_rti_add_customer; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_rti_add_customer (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_rti_add_customer OWNER TO poststress;

--
-- Name: a_rti_add_phone; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_rti_add_phone (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_rti_add_phone OWNER TO poststress;

--
-- Name: a_shift; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_shift (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_shift OWNER TO poststress;

--
-- Name: a_workstep; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.a_workstep (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    action_name character varying(64),
    action_alias character varying(64),
    action_source character varying(64),
    action_sourcename character varying(64),
    action_methodname character varying(64)
);


ALTER TABLE public.a_workstep OWNER TO poststress;

--
-- Name: allergy; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.allergy (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.allergy OWNER TO poststress;

--
-- Name: batch; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.batch (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    products uuid[],
    product_number integer,
    product_priority integer,
    worksteps uuid[]
);


ALTER TABLE public.batch OWNER TO poststress;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.customer (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    lastname character varying(255),
    firstname character varying(255),
    straat character varying(255),
    created_on timestamp(3) without time zone,
    customer_room_number character varying(255),
    customer_diet uuid[],
    customer_allergy uuid[],
    customer_insuline_morning integer,
    customer_insuline_noon integer,
    customer_insuline_evening integer,
    customer_help_feeding integer,
    customer_swallow_prob integer,
    customer_does_not_like uuid[],
    customer_standard_amout_bread integer,
    customer_standard_amout_charcuterie integer,
    customer_texture uuid,
    customer_portion uuid
);


ALTER TABLE public.customer OWNER TO poststress;

--
-- Name: cycle_routine; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.cycle_routine (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    routine uuid,
    routine_class character varying(255),
    cycle uuid,
    parent uuid[],
    parent_class character varying(255),
    children uuid[],
    child_class character varying(255),
    created_on timestamp(3) without time zone
);


ALTER TABLE public.cycle_routine OWNER TO poststress;

--
-- Name: cycles; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.cycles (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    routines uuid[],
    amount_of_processors integer,
    startnumber_of_processors integer,
    workstation_name character varying(255),
    current_routine uuid,
    created_on timestamp(3) without time zone
);


ALTER TABLE public.cycles OWNER TO poststress;

--
-- Name: diet; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.diet (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.diet OWNER TO poststress;

--
-- Name: does_not_like; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.does_not_like (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.does_not_like OWNER TO poststress;

--
-- Name: empl_group; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.empl_group (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    description text,
    level integer,
    created_on timestamp(3) without time zone
);


ALTER TABLE public.empl_group OWNER TO poststress;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.employee (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    email text,
    password text,
    sure_name character varying(255),
    famely_name character varying(255),
    employee_groups uuid[],
    created_on timestamp(3) without time zone,
    name text
);


ALTER TABLE public.employee OWNER TO poststress;

--
-- Name: errors_living_obj_mach; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.errors_living_obj_mach (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    standard_errors text[],
    custom_errors text[],
    created_on timestamp(3) without time zone
);


ALTER TABLE public.errors_living_obj_mach OWNER TO poststress;

--
-- Name: food_bread; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_bread (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_bread OWNER TO poststress;

--
-- Name: food_breakfast; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_breakfast (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    breakfast_customer uuid,
    breakfast_perpared integer,
    breakfast_location uuid,
    breakfast_bread uuid,
    breakfast_amount_bread integer,
    breakfast_smear integer,
    breakfast_crusts integer,
    breakfast_butter uuid,
    comment text,
    breakfast_drinks uuid[],
    breakfast_charcuterie uuid[],
    breakfast_amount_charcuterie integer,
    breakfast_drinkservice uuid,
    breakfast_sugar uuid,
    breakfast_dessert uuid,
    breakfast_napkin integer,
    breakfast_paper uuid,
    breakfast_date timestamp(3) without time zone
);


ALTER TABLE public.food_breakfast OWNER TO poststress;

--
-- Name: food_butter; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_butter (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_butter OWNER TO poststress;

--
-- Name: food_charcuterie; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_charcuterie (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text,
    charcuterie_available integer
);


ALTER TABLE public.food_charcuterie OWNER TO poststress;

--
-- Name: food_dessert; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_dessert (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_dessert OWNER TO poststress;

--
-- Name: food_dinner; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_dinner (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    dinner_customer uuid,
    dinner_perpared integer,
    dinner_location uuid,
    dinner_bread uuid,
    dinner_amount_bread integer,
    dinner_smear integer,
    dinner_crusts integer,
    dinner_butter uuid,
    comment text,
    dinner_drinks uuid[],
    dinner_charcuterie uuid[],
    dinner_amount_charcuterie integer,
    dinner_drinkservice uuid,
    dinner_sugar uuid,
    dinner_dessert uuid,
    dinner_napkin integer,
    dinner_date timestamp(3) without time zone
);


ALTER TABLE public.food_dinner OWNER TO poststress;

--
-- Name: food_drink; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_drink (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_drink OWNER TO poststress;

--
-- Name: food_drinkserivce; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_drinkserivce (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_drinkserivce OWNER TO poststress;

--
-- Name: food_lunch; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_lunch (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text,
    lunch_customer uuid,
    lunch_perpared integer,
    lunch_location uuid,
    lunch_texture uuid,
    lunch_portion uuid,
    lunch_plate integer,
    lunch_drinks uuid[],
    lunch_apiritif uuid,
    lunch_napkin integer,
    lunch_date timestamp(3) without time zone
);


ALTER TABLE public.food_lunch OWNER TO poststress;

--
-- Name: food_place; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_place (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_place OWNER TO poststress;

--
-- Name: food_portion; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_portion (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_portion OWNER TO poststress;

--
-- Name: food_sugar; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_sugar (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_sugar OWNER TO poststress;

--
-- Name: food_texture; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.food_texture (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.food_texture OWNER TO poststress;

--
-- Name: linkeddoc; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.linkeddoc (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    file_name text,
    file_path text,
    file_type integer,
    file_names_extra text[],
    comment text
);


ALTER TABLE public.linkeddoc OWNER TO poststress;

--
-- Name: living_obj_mach; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.living_obj_mach (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    datum_start timestamp without time zone,
    datum_stop timestamp without time zone,
    timer_cycle integer,
    socket_port integer,
    socket_ip text,
    workstation_name text,
    commands_todo text[],
    commands_done text[],
    command_replay_history text[],
    connection_state integer,
    device_state integer,
    device_filetransfer integer,
    error_table uuid,
    current_error text,
    ws_tech integer,
    created_on timestamp(3) without time zone
);


ALTER TABLE public.living_obj_mach OWNER TO poststress;

--
-- Name: mach_group; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.mach_group (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    mach_group_machs uuid[],
    mach_group_planning uuid
);


ALTER TABLE public.mach_group OWNER TO poststress;

--
-- Name: operation; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.operation (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    object uuid,
    objects uuid[],
    datum_start timestamp(3) without time zone,
    datum_stop timestamp(3) without time zone,
    h2o_value double precision,
    performed_workstep uuid,
    operation_state integer,
    operation_source integer,
    operation_closed_cause integer,
    operation_error_information text,
    created_on timestamp(3) without time zone
);


ALTER TABLE public.operation OWNER TO poststress;

--
-- Name: paper; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.paper (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    comment text
);


ALTER TABLE public.paper OWNER TO poststress;

--
-- Name: planning; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.planning (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    overlap_time integer,
    pre_prep integer,
    post_prep integer,
    planning_shift uuid
);


ALTER TABLE public.planning OWNER TO poststress;

--
-- Name: product; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.product (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    previous_workstep uuid,
    current_workstep uuid,
    next_workstep uuid,
    product_state integer,
    product_ws_state integer,
    product_index integer
);


ALTER TABLE public.product OWNER TO poststress;

--
-- Name: rti_add_chef; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.rti_add_chef (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    source_type character varying(255),
    source_file character varying(255),
    method_name character varying(255),
    employee uuid,
    person uuid
);


ALTER TABLE public.rti_add_chef OWNER TO poststress;

--
-- Name: rti_add_customer; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.rti_add_customer (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    source_type character varying(255),
    source_file character varying(255),
    method_name character varying(255),
    employee uuid,
    person uuid
);


ALTER TABLE public.rti_add_customer OWNER TO poststress;

--
-- Name: rti_add_phone; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.rti_add_phone (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    source_type character varying(255),
    source_file character varying(255),
    method_name character varying(255),
    employee uuid,
    person uuid
);


ALTER TABLE public.rti_add_phone OWNER TO poststress;

--
-- Name: shift; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.shift (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    created_on timestamp(3) without time zone,
    shift_start_monday timestamp without time zone,
    shift_start_tuesday timestamp without time zone,
    shift_start_wednesday timestamp without time zone,
    shift_start_thursday timestamp without time zone,
    shift_start_friday timestamp without time zone,
    shift_start_saturday timestamp without time zone,
    shift_start_sunday timestamp without time zone,
    shift_stop_monday timestamp without time zone,
    shift_stop_tuesday timestamp without time zone,
    shift_stop_wednesday timestamp without time zone,
    shift_stop_thursday timestamp without time zone,
    shift_stop_friday timestamp without time zone,
    shift_stop_saturday timestamp without time zone,
    shift_stop_sunday timestamp without time zone
);


ALTER TABLE public.shift OWNER TO poststress;

--
-- Name: workstep; Type: TABLE; Schema: public; Owner: poststress
--

CREATE TABLE public.workstep (
    pkey uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name character varying(255),
    ws_tech integer,
    ws_assigned uuid,
    ws_workplace uuid,
    created_on timestamp(3) without time zone,
    ws_state integer,
    ws_performed_by uuid,
    ws_planned_start timestamp without time zone,
    ws_planned_stop timestamp without time zone,
    linked_documents uuid[],
    ws_mach_group uuid,
    ws_include_planning integer
);


ALTER TABLE public.workstep OWNER TO poststress;

--
-- Data for Name: a_allergy; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_allergy (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_batch; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_batch (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_customer; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_customer (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
82c01b4e-aea4-11ef-8d94-2cf05d44ba6c	createQrCode	create qr code	DLL	clCreateQrCodeOfObject.dll	doMethod
538b119c-afb4-11ef-8d95-2cf05d44ba6c	ShowQrCodeOfObject	Show Qr code of object	DLL	clShowQrCodeOfObject.dll	doMethod
\.


--
-- Data for Name: a_cycle_routine; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_cycle_routine (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_cycles; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_cycles (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_diet; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_diet (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_does_not_like; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_does_not_like (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_empl_group; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_empl_group (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_employee; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_employee (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
3849bf36-b70d-11ef-8da1-2cf05d44ba6c	ExportToExcel	Export to excel	DLL	clExportToExcel.dll	doMethod
\.


--
-- Data for Name: a_errors_living_obj_mach; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_errors_living_obj_mach (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_bread; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_bread (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_breakfast; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_breakfast (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_butter; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_butter (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_charcuterie; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_charcuterie (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_dessert; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_dessert (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_dinner; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_dinner (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_drink; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_drink (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_drinkserivce; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_drinkserivce (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_lunch; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_lunch (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_place; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_place (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_portion; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_portion (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_sugar; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_sugar (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_food_texture; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_food_texture (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_linkeddoc; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_linkeddoc (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
23b417bc-c2b9-11ef-b320-2cf05d44ba6c	OpenLinkedDoc	OpenLinkedDoc	DLL	clOpenLinkedDoc.dll	doMethod
\.


--
-- Data for Name: a_living_obj_mach; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_living_obj_mach (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_mach_group; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_mach_group (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_operation; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_operation (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_paper; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_paper (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_planning; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_planning (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_product; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_product (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_rti_add_chef; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_rti_add_chef (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_rti_add_customer; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_rti_add_customer (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_rti_add_phone; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_rti_add_phone (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_shift; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_shift (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
\.


--
-- Data for Name: a_workstep; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.a_workstep (pkey, action_name, action_alias, action_source, action_sourcename, action_methodname) FROM stdin;
4307d46a-c245-11ef-b317-2cf05d44ba6c	SaveLinkedDoc	SaveLinkedDoc	DLL	clSaveLinkedDoc.dll	doMethod
0cf215c4-c2b9-11ef-b31f-2cf05d44ba6c	OpenLinkedDoc	OpenLinkedDoc	DLL	clOpenLinkedDoc.dll	doMethod
\.


--
-- Data for Name: allergy; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.allergy (pkey, name, created_on, comment) FROM stdin;
361148dc-0d6c-11f0-8cee-2cf05d44ba6c	tomaten	2025-03-30 15:37:59.511	
\.


--
-- Data for Name: batch; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.batch (pkey, name, created_on, products, product_number, product_priority, worksteps) FROM stdin;
d8fa2a4c-e7f5-11ef-849a-2cf05d44ba6c	Batch_02	2025-02-10 22:26:55.9	{d8f3f1b8-e7f5-11ef-8490-2cf05d44ba6c,d8f60f2a-e7f5-11ef-8491-2cf05d44ba6c,d8f6927e-e7f5-11ef-8492-2cf05d44ba6c,d8f6faca-e7f5-11ef-8493-2cf05d44ba6c,d8f6facb-e7f5-11ef-8494-2cf05d44ba6c,d8f6facc-e7f5-11ef-8495-2cf05d44ba6c,d8f6facd-e7f5-11ef-8496-2cf05d44ba6c,d8f8616c-e7f5-11ef-8497-2cf05d44ba6c,d8f8616d-e7f5-11ef-8498-2cf05d44ba6c,d8f9c796-e7f5-11ef-8499-2cf05d44ba6c}	10	3	{}
125431d0-e598-11ef-a3e4-2cf05d44ba6c	Batch_01	2024-02-10 20:59:24.111	{1251aece-e598-11ef-a3df-2cf05d44ba6c,1252609e-e598-11ef-a3e0-2cf05d44ba6c,1252ee10-e598-11ef-a3e1-2cf05d44ba6c}	3	11	{2fc4ba9a-e670-11ef-ac51-2cf05d44ba6c,4d13e1d4-e670-11ef-ac52-2cf05d44ba6c,661b545a-e670-11ef-ac53-2cf05d44ba6c}
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.customer (pkey, name, lastname, firstname, straat, created_on, customer_room_number, customer_diet, customer_allergy, customer_insuline_morning, customer_insuline_noon, customer_insuline_evening, customer_help_feeding, customer_swallow_prob, customer_does_not_like, customer_standard_amout_bread, customer_standard_amout_charcuterie, customer_texture, customer_portion) FROM stdin;
3fbbf25e-0d6e-11f0-8cef-2cf05d44ba6c	Aneca	Aneca	Robert		2025-03-30 15:50:47.641	K004	{}	{}	0	0	1	2	1	{4f489f88-0d6e-11f0-8cf0-2cf05d44ba6c,552926f2-0d6e-11f0-8cf1-2cf05d44ba6c,615dd7ec-0d6e-11f0-8cf2-2cf05d44ba6c,6806973c-0d6e-11f0-8cf3-2cf05d44ba6c}	2	2	9d075cc0-0d67-11f0-ad9a-2cf05d44ba6c	44fc1bce-0d67-11f0-ad97-2cf05d44ba6c
e3b9c2fa-0d6e-11f0-8cf4-2cf05d44ba6c	Erna	Beirens	Erna		2025-03-30 15:55:48.37	K505	{}	{}	0	0	0	0	0	{}	2	2	\N	\N
83327a98-0d79-11f0-8d00-2cf05d44ba6c	Jenny	Constant	Jenny		2025-03-30 17:11:16.033	K107	{}	{}	0	0	0	0	0	{}	2	2	aae635fa-0d67-11f0-ad9d-2cf05d44ba6c	4cef26c8-0d67-11f0-ad98-2cf05d44ba6c
\.


--
-- Data for Name: cycle_routine; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.cycle_routine (pkey, name, routine, routine_class, cycle, parent, parent_class, children, child_class, created_on) FROM stdin;
3d316dc0-a11c-11ef-9b2f-2cf05d44ba6c	Cycle_02_Phone_03	efa26564-a11b-11ef-9b2c-2cf05d44ba6c	rti_add_phone	f326dbbe-a113-11ef-8fe4-2cf05d44ba6c	{}	CYCLES	{}	CYCLES	\N
674be802-c317-11ef-b34c-2cf05d44ba6c	Cycle_01_Phone_03	efa26564-a11b-11ef-9b2c-2cf05d44ba6c	rti_add_phone	e2ef553c-a113-11ef-8fe3-2cf05d44ba6c	{25fab38c-a11c-11ef-9b2e-2cf05d44ba6c}		{}	CYCLES	\N
20fb4ca2-a11c-11ef-9b2d-2cf05d44ba6c	Cycle_01_Phone_01_messageToAddPhoneNumber	974af782-a11b-11ef-9b2a-2cf05d44ba6c	rti_add_phone	e2ef553c-a113-11ef-8fe3-2cf05d44ba6c	{25fab38c-a11c-11ef-9b2e-2cf05d44ba6c}		{}	CYCLES	\N
25fab38c-a11c-11ef-9b2e-2cf05d44ba6c	Cycle_01_Phone_02_checkIfEmployerExists	ccc8864a-a11b-11ef-9b2b-2cf05d44ba6c	rti_add_phone	e2ef553c-a113-11ef-8fe3-2cf05d44ba6c	{}	CYCLES	{20fb4ca2-a11c-11ef-9b2d-2cf05d44ba6c,674be802-c317-11ef-b34c-2cf05d44ba6c}		2000-01-01 00:00:00
\.


--
-- Data for Name: cycles; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.cycles (pkey, name, routines, amount_of_processors, startnumber_of_processors, workstation_name, current_routine, created_on) FROM stdin;
e2ef553c-a113-11ef-8fe3-2cf05d44ba6c	Cycle_01	{}	4	2	5AXE-MINI	20fb4ca2-a11c-11ef-9b2d-2cf05d44ba6c	\N
f326dbbe-a113-11ef-8fe4-2cf05d44ba6c	Cycle_02	{}	4	2	5AXE-MINI	\N	\N
\.


--
-- Data for Name: diet; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.diet (pkey, name, created_on, comment) FROM stdin;
d821a748-0d67-11f0-ad9e-2cf05d44ba6c	SA	2025-03-30 15:06:46.251	
df80c898-0d67-11f0-ad9f-2cf05d44ba6c	ALCVR	2025-03-30 15:06:53.091	
ec652b62-0d67-11f0-ada0-2cf05d44ba6c	Glutten + lactosevrij	2025-03-30 15:07:05.34	
f5059a72-0d67-11f0-ada1-2cf05d44ba6c	Lactosevrij	2025-03-30 15:07:29.642	
\.


--
-- Data for Name: does_not_like; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.does_not_like (pkey, name, created_on, comment) FROM stdin;
4f489f88-0d6e-11f0-8cf0-2cf05d44ba6c	rijst	2025-03-30 15:53:02.261	
552926f2-0d6e-11f0-8cf1-2cf05d44ba6c	spaghetti	2025-03-30 15:53:10.186	
615dd7ec-0d6e-11f0-8cf2-2cf05d44ba6c	macaroni	2025-03-30 15:53:19.85	
6806973c-0d6e-11f0-8cf3-2cf05d44ba6c	rauwkost	2025-03-30 15:53:43.16	
\.


--
-- Data for Name: empl_group; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.empl_group (pkey, name, description, level, created_on) FROM stdin;
1bee2fac-ab78-11ef-9bec-2cf05d44ba6c	Verplegers	Verpleegkundigen	30	2024-11-25 22:56:59
f80ad068-ab77-11ef-9beb-2cf05d44ba6c	R&D	Research and development	40	2024-11-25 22:57:05
27d75404-ab75-11ef-82ff-2cf05d44ba6c	Cleaners	Cleaning the bulding	30	2024-11-25 22:57:11
5004e9b6-ab78-11ef-9bee-2cf05d44ba6c	Cooks	Cooks	30	2024-11-25 22:57:29
\.


--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.employee (pkey, email, password, sure_name, famely_name, employee_groups, created_on, name) FROM stdin;
18521866-a10c-11ef-8fdf-2cf05d44ba6c	jean.vandorpe@gmail.com	test	Jean	Vandorpe	{1bee2fac-ab78-11ef-9bec-2cf05d44ba6c,5004e9b6-ab78-11ef-9bee-2cf05d44ba6c}	2024-11-25 23:07:00	Jean
c7399988-a113-11ef-8fe2-2cf05d44ba6c	wouter.vandorpe.2UVframework@hotmail.com	1234	Wouter	Vandorpe	{27d75404-ab75-11ef-82ff-2cf05d44ba6c,f80ad068-ab77-11ef-9beb-2cf05d44ba6c}	2019-11-25 23:06:20	Wouter
\.


--
-- Data for Name: errors_living_obj_mach; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.errors_living_obj_mach (pkey, name, standard_errors, custom_errors, created_on) FROM stdin;
64625ea6-a106-11ef-8fd8-2cf05d44ba6c	Machine_01	{500;Socket,10010;approx,20010;something}	{"10020;99999 Error",20500;testing}	\N
\.


--
-- Data for Name: food_bread; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_bread (pkey, name, created_on, comment) FROM stdin;
2380bc04-0d6f-11f0-8cf8-2cf05d44ba6c	bruin	2025-03-30 15:58:57.561	
27e7ec22-0d6f-11f0-8cf9-2cf05d44ba6c	melkbrood	2025-03-30 15:59:05.915	
2f9fb706-0d6f-11f0-8cfa-2cf05d44ba6c	rozijnenbrood	2025-03-30 15:59:14.43	
35f540e4-0d6f-11f0-8cfb-2cf05d44ba6c	sandwich	2025-03-30 15:59:26.592	
3acd5048-0d6f-11f0-8cfc-2cf05d44ba6c	suikerbol	2025-03-30 15:59:38.376	
\.


--
-- Data for Name: food_breakfast; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_breakfast (pkey, name, created_on, breakfast_customer, breakfast_perpared, breakfast_location, breakfast_bread, breakfast_amount_bread, breakfast_smear, breakfast_crusts, breakfast_butter, comment, breakfast_drinks, breakfast_charcuterie, breakfast_amount_charcuterie, breakfast_drinkservice, breakfast_sugar, breakfast_dessert, breakfast_napkin, breakfast_paper, breakfast_date) FROM stdin;
703f2082-10c9-11f0-ac0e-2cf05d44ba6c	test	2025-04-04 18:34:11	e3b9c2fa-0d6e-11f0-8cf4-2cf05d44ba6c	0	0688fe40-0d6f-11f0-8cf6-2cf05d44ba6c	2f9fb706-0d6f-11f0-8cfa-2cf05d44ba6c	2	0	1	510e48f8-0d6f-11f0-8cfe-2cf05d44ba6c	2	{de65f858-0e5b-11f0-814f-2cf05d44ba6c,de65f858-0e5b-11f0-814f-2cf05d44ba6c,e98a3a78-0e5b-11f0-8150-2cf05d44ba6c,e98a3a78-0e5b-11f0-8150-2cf05d44ba6c}	{9d03962a-0e5d-11f0-8153-2cf05d44ba6c,a22c219e-0e5d-11f0-8154-2cf05d44ba6c,a90d6162-0e5d-11f0-8155-2cf05d44ba6c}	2	\N	\N	\N	1	1788c0ac-0d6c-11f0-8ced-2cf05d44ba6c	2025-04-04 00:00:00
02e629de-10c6-11f0-ac06-2cf05d44ba6c	test	2025-04-03 20:31:16	3fbbf25e-0d6e-11f0-8cef-2cf05d44ba6c	0	0aa1901e-0d6f-11f0-8cf7-2cf05d44ba6c	2380bc04-0d6f-11f0-8cf8-2cf05d44ba6c	2	1	1	6c6c72c8-0d6f-11f0-8cff-2cf05d44ba6c	2	{e98a3a78-0e5b-11f0-8150-2cf05d44ba6c,fc4cf09c-0e5b-11f0-8151-2cf05d44ba6c}	{9d03962a-0e5d-11f0-8153-2cf05d44ba6c,a22c219e-0e5d-11f0-8154-2cf05d44ba6c}	2	\N	\N	\N	1	123de64a-0d6c-11f0-8cec-2cf05d44ba6c	2025-04-03 00:00:00
\.


--
-- Data for Name: food_butter; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_butter (pkey, name, created_on, comment) FROM stdin;
4acda312-0d6f-11f0-8cfd-2cf05d44ba6c	boter	2025-03-30 16:00:03.72	
510e48f8-0d6f-11f0-8cfe-2cf05d44ba6c	becel	2025-03-30 16:00:12.05	
6c6c72c8-0d6f-11f0-8cff-2cf05d44ba6c	niets	2025-03-30 16:01:01.69	
\.


--
-- Data for Name: food_charcuterie; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_charcuterie (pkey, name, created_on, comment, charcuterie_available) FROM stdin;
9d03962a-0e5d-11f0-8153-2cf05d44ba6c	salami	2025-03-31 20:25:55.573		0
a22c219e-0e5d-11f0-8154-2cf05d44ba6c	hesp	2025-03-31 20:26:11.257		1
a90d6162-0e5d-11f0-8155-2cf05d44ba6c	kaas	2025-03-31 20:26:21.236		1
\.


--
-- Data for Name: food_dessert; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_dessert (pkey, name, created_on, comment) FROM stdin;
\.


--
-- Data for Name: food_dinner; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_dinner (pkey, name, created_on, dinner_customer, dinner_perpared, dinner_location, dinner_bread, dinner_amount_bread, dinner_smear, dinner_crusts, dinner_butter, comment, dinner_drinks, dinner_charcuterie, dinner_amount_charcuterie, dinner_drinkservice, dinner_sugar, dinner_dessert, dinner_napkin, dinner_date) FROM stdin;
202167a6-114e-11f0-ac0f-2cf05d44ba6c	TEst	2025-04-04 17:50:07	e3b9c2fa-0d6e-11f0-8cf4-2cf05d44ba6c	1	0688fe40-0d6f-11f0-8cf6-2cf05d44ba6c	2f9fb706-0d6f-11f0-8cfa-2cf05d44ba6c	2	1	1	510e48f8-0d6f-11f0-8cfe-2cf05d44ba6c		{de65f858-0e5b-11f0-814f-2cf05d44ba6c,e98a3a78-0e5b-11f0-8150-2cf05d44ba6c,fc4cf09c-0e5b-11f0-8151-2cf05d44ba6c}	{9d03962a-0e5d-11f0-8153-2cf05d44ba6c,a22c219e-0e5d-11f0-8154-2cf05d44ba6c,a90d6162-0e5d-11f0-8155-2cf05d44ba6c}	0	\N	\N	\N	1	2025-04-04 00:00:00
\.


--
-- Data for Name: food_drink; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_drink (pkey, name, created_on, comment) FROM stdin;
de65f858-0e5b-11f0-814f-2cf05d44ba6c	Glas water	2025-03-31 20:13:27.923	
e98a3a78-0e5b-11f0-8150-2cf05d44ba6c	Glas cola	2025-03-31 20:13:47.92	
fc4cf09c-0e5b-11f0-8151-2cf05d44ba6c	Glas Fanta	2025-03-31 20:14:19.505	
0880e5b2-0e5c-11f0-8152-2cf05d44ba6c	Mok koffie	2025-03-31 20:14:37.404	
\.


--
-- Data for Name: food_drinkserivce; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_drinkserivce (pkey, name, created_on, comment) FROM stdin;
\.


--
-- Data for Name: food_lunch; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_lunch (pkey, name, created_on, comment, lunch_customer, lunch_perpared, lunch_location, lunch_texture, lunch_portion, lunch_plate, lunch_drinks, lunch_apiritif, lunch_napkin, lunch_date) FROM stdin;
\.


--
-- Data for Name: food_place; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_place (pkey, name, created_on, comment) FROM stdin;
0147e57c-0d6f-11f0-8cf5-2cf05d44ba6c	resto	2025-03-30 15:58:00.58	
0688fe40-0d6f-11f0-8cf6-2cf05d44ba6c	lounge	2025-03-30 15:58:08.332	
0aa1901e-0d6f-11f0-8cf7-2cf05d44ba6c	buiten	2025-03-30 15:58:17.384	
\.


--
-- Data for Name: food_portion; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_portion (pkey, name, created_on, comment) FROM stdin;
44fc1bce-0d67-11f0-ad97-2cf05d44ba6c	groot	2025-03-30 15:02:28.3	grote portie
4cef26c8-0d67-11f0-ad98-2cf05d44ba6c	normaal	2025-03-30 15:02:46.45	normale portie
572f511c-0d67-11f0-ad99-2cf05d44ba6c	klein	2025-03-30 15:02:59.742	kleine portie
\.


--
-- Data for Name: food_sugar; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_sugar (pkey, name, created_on, comment) FROM stdin;
\.


--
-- Data for Name: food_texture; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.food_texture (pkey, name, created_on, comment) FROM stdin;
9d075cc0-0d67-11f0-ad9a-2cf05d44ba6c	gemixt	2025-03-30 15:05:03.44	
a1febb60-0d67-11f0-ad9b-2cf05d44ba6c	gesneden	2025-03-30 15:05:14.172	
a6b61702-0d67-11f0-ad9c-2cf05d44ba6c	gemalen	2025-03-30 15:05:22.81	
aae635fa-0d67-11f0-ad9d-2cf05d44ba6c	normaal	2025-03-30 15:05:29.91	
\.


--
-- Data for Name: linkeddoc; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.linkeddoc (pkey, name, created_on, file_name, file_path, file_type, file_names_extra, comment) FROM stdin;
0384550c-c2d6-11ef-b322-2cf05d44ba6c	2UV_02.png	2024-12-25 15:36:30	2UV_02.png	\N	0	\N	\N
15f30986-c2d6-11ef-b323-2cf05d44ba6c	2UV_01.png	2024-12-25 15:37:01	2UV_01.png	\N	0	\N	\N
58448224-c2d6-11ef-b324-2cf05d44ba6c	2UV_01.png	2024-12-25 15:38:53	2UV_01.png	\N	0	\N	\N
e6949212-c2d6-11ef-b325-2cf05d44ba6c	2UV_01.png	2024-12-25 15:42:51	2UV_01.png	\N	0	\N	\N
ec5d7f56-c2d6-11ef-b326-2cf05d44ba6c	2UV_01.png	2024-12-25 15:43:01	2UV_01.png	\N	0	\N	\N
f34a2648-c2d6-11ef-b327-2cf05d44ba6c	2UV_01.png	2024-12-25 15:43:13	2UV_01.png	\N	0	\N	\N
24ea40d4-c2d7-11ef-b328-2cf05d44ba6c	2UV_01.png	2024-12-25 15:44:36	2UV_01.png	\N	0	\N	\N
a6051d42-c2d7-11ef-b329-2cf05d44ba6c	2UV_01.png	2024-12-25 15:48:13	2UV_01.png	\N	0	\N	\N
40112aac-c2d8-11ef-b32a-2cf05d44ba6c	2UV_01.png	2024-12-25 15:52:31	2UV_01.png	\N	0	\N	\N
9c030d58-c2d8-11ef-b32b-2cf05d44ba6c	2UV_01.png	2024-12-25 15:55:05	2UV_01.png	\N	0	\N	\N
a23aa69a-c2d8-11ef-b32c-2cf05d44ba6c	contact test.png	2024-12-25 15:55:16	contact test.png	\N	0	\N	\N
20d2ad0e-c2d9-11ef-b32d-2cf05d44ba6c	contact test.png	2024-12-25 15:58:48	contact test.png	\N	0	\N	\N
8eed37be-c2d9-11ef-b32e-2cf05d44ba6c	contact test.png	2024-12-25 16:01:53	contact test.png	\N	0	\N	\N
ab9a96a4-c2d9-11ef-b32f-2cf05d44ba6c	2UV_02.png	2024-12-25 16:02:41	2UV_02.png	\N	0	\N	\N
72b55df6-c2e3-11ef-b330-2cf05d44ba6c	2UV_02.png	2024-12-25 17:12:40	2UV_02.png	\N	0	\N	\N
d1f6284a-c2e3-11ef-b331-2cf05d44ba6c	2UV_02.png	2024-12-25 17:15:20	2UV_02.png	\N	0	\N	\N
2ff81fd4-c2e4-11ef-b332-2cf05d44ba6c	2UV_02.png	2024-12-25 17:17:58	2UV_02.png	\N	0	\N	\N
385cc5d0-c2e4-11ef-b333-2cf05d44ba6c	2UV.png	2024-12-25 17:18:12	2UV.png	\N	0	\N	\N
269383f4-c2f1-11ef-b338-2cf05d44ba6c	2UV_02.png	2024-12-25 18:50:46	2UV_02.png	\N	0	\N	\N
2f29863a-c2f1-11ef-b339-2cf05d44ba6c	test.png	2024-12-25 18:51:00	test.png	\N	0	\N	\N
0b8310de-c2f6-11ef-b33a-2cf05d44ba6c	2UV_02.png	2024-12-25 19:25:48	2UV_02.png	\N	0	\N	\N
1534a976-c2f6-11ef-b33b-2cf05d44ba6c	contact test.png	2024-12-25 19:26:04	contact test.png	\N	0	\N	\N
25624042-c2f6-11ef-b33c-2cf05d44ba6c	download.jpg	2024-12-25 19:26:31	download.jpg	\N	0	\N	\N
30eab638-c2f6-11ef-b33d-2cf05d44ba6c	contact test.png	2024-12-25 19:26:51	contact test.png	\N	0	\N	\N
7e18fff0-c2f6-11ef-b33e-2cf05d44ba6c	tandwiel.png	2024-12-25 19:29:00	tandwiel.png	\N	0	\N	\N
bb5ab610-c2f6-11ef-b33f-2cf05d44ba6c	Untitled.xcf	2024-12-25 19:30:43	Untitled.xcf	\N	0	\N	\N
c0fba688-c2f6-11ef-b340-2cf05d44ba6c	contact test.png	2024-12-25 19:30:52	contact test.png	\N	0	\N	\N
f463cb4e-c2f7-11ef-b341-2cf05d44ba6c	2UV.png	2024-12-25 19:39:28	2UV.png	\N	0	\N	\N
0f835b7e-c2f8-11ef-b342-2cf05d44ba6c	Untitled.png	2024-12-25 19:40:13	Untitled.png	\N	0	\N	\N
21a74f9a-c2f8-11ef-b343-2cf05d44ba6c	2UV_01.png	2024-12-25 19:40:44	2UV_01.png	\N	0	\N	\N
2321dfbe-c2fa-11ef-b344-2cf05d44ba6c	2UV.xcf	2024-12-25 19:55:05	2UV.xcf	\N	0	\N	\N
87348196-c2ff-11ef-b346-2cf05d44ba6c	service.jpg	2024-12-25 20:33:41	service.jpg	\N	0	\N	\N
03f5ec2c-c302-11ef-b348-2cf05d44ba6c		2024-12-25 20:51:29		\N	0	\N	\N
0ae1cc86-c302-11ef-b349-2cf05d44ba6c	contact test.png	2024-12-25 20:51:41	contact test.png	\N	0	\N	\N
a69bad72-c30c-11ef-b34a-2cf05d44ba6c	1735164446348904700809154102115.jpg	2024-12-25 22:07:37	1735164446348904700809154102115.jpg	\N	0	\N	\N
f2a2ccc4-c310-11ef-b34b-2cf05d44ba6c	2UV_02.png	2024-12-25 22:38:22	2UV_02.png	\N	0	\N	\N
0538d61c-c36b-11ef-b34d-2cf05d44ba6c	netwoork_create.bat	2024-12-26 09:23:09	netwoork_create.bat	\N	0	\N	\N
566bde7c-c379-11ef-b34e-2cf05d44ba6c	17352110830336171624991900172499.jpg	2024-12-26 11:05:38	17352110830336171624991900172499.jpg	\N	0	\N	\N
8b8b59ac-c379-11ef-b34f-2cf05d44ba6c	17352110830336171624991900172499.jpg	2024-12-26 11:07:07	17352110830336171624991900172499.jpg	\N	0	\N	\N
8c5d589e-c379-11ef-b350-2cf05d44ba6c	17352110830336171624991900172499.jpg	2024-12-26 11:07:09	17352110830336171624991900172499.jpg	\N	0	\N	\N
9766ffe2-c379-11ef-b351-2cf05d44ba6c	17352110830336171624991900172499.jpg	2024-12-26 11:07:27	17352110830336171624991900172499.jpg	\N	0	\N	\N
98d79102-c3b5-11ef-b352-2cf05d44ba6c	autorun.ico	2024-12-26 18:17:00	autorun.ico	\N	0	\N	\N
1d61df66-d902-11ef-9a74-2cf05d44ba6c	config.client.Server	2025-01-22 21:47:37	config.client.Server	\N	0	\N	\N
588ae2b8-0fc1-11f0-abef-2cf05d44ba6c		2025-04-02 12:52:33		\N	0	\N	\N
\.


--
-- Data for Name: living_obj_mach; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.living_obj_mach (pkey, name, datum_start, datum_stop, timer_cycle, socket_port, socket_ip, workstation_name, commands_todo, commands_done, command_replay_history, connection_state, device_state, device_filetransfer, error_table, current_error, ws_tech, created_on) FROM stdin;
a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c	Machine_01	2024-11-12 22:03:27	2024-11-12 22:03:27	1000	1234	192.168.1.210	5AXE-MINI	{}	{}	{}	0	10	0	64625ea6-a106-11ef-8fd8-2cf05d44ba6c		300	\N
8bc75366-e323-11ef-a3d4-2cf05d44ba6c	Machine_02	2025-02-04 19:11:47	2025-02-04 19:11:47	0	0			{}	{}	{}	0	100	0	\N		300	\N
94e306d4-e323-11ef-a3d5-2cf05d44ba6c	Machine_03	2025-02-04 19:12:13	2025-02-04 19:12:13	0	0			{}	{}	{}	0	0	0	\N		200	\N
9dbed850-e323-11ef-a3d6-2cf05d44ba6c	Machine_04	2025-02-04 19:12:28	2025-02-04 19:12:28	0	0			{}	{}	{}	0	0	0	\N		200	\N
\.


--
-- Data for Name: mach_group; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.mach_group (pkey, name, created_on, mach_group_machs, mach_group_planning) FROM stdin;
40c3264c-e323-11ef-a3d1-2cf05d44ba6c	MachineGroup_01	2025-02-04 19:10:50	{a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c}	c767f664-e328-11ef-a3d9-2cf05d44ba6c
4f518988-e323-11ef-a3d2-2cf05d44ba6c	MachineGroup_02	2025-02-04 19:12:56	{8bc75366-e323-11ef-a3d4-2cf05d44ba6c}	c767f664-e328-11ef-a3d9-2cf05d44ba6c
57541f56-e323-11ef-a3d3-2cf05d44ba6c	MachineGroup_03	2025-02-04 19:14:13	{94e306d4-e323-11ef-a3d5-2cf05d44ba6c,9dbed850-e323-11ef-a3d6-2cf05d44ba6c}	e65fbfde-e328-11ef-a3da-2cf05d44ba6c
\.


--
-- Data for Name: operation; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.operation (pkey, name, object, objects, datum_start, datum_stop, h2o_value, performed_workstep, operation_state, operation_source, operation_closed_cause, operation_error_information, created_on) FROM stdin;
e7a98924-a390-11ef-926c-2cf05d44ba6c	System Machine_01	a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c	{a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c}	2024-11-15 21:33:42	2024-11-15 21:33:51	\N	\N	20	40	10		\N
f8fd503e-a390-11ef-926d-2cf05d44ba6c	System Machine_01	a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c	{a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c}	2024-11-15 21:34:11	2024-11-15 21:34:21	\N	\N	20	40	10		\N
ef9a3b2a-ae7f-11ef-8562-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 18:29:57	2024-11-29 18:59:57	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
b0091d36-ae80-11ef-8563-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 18:35:20	2024-11-29 18:59:57	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
3f39cd18-ae84-11ef-8568-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 19:00:49	2024-11-29 19:00:53	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
b982c852-ae81-11ef-8567-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 18:42:45	2024-11-29 19:01:42	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
9e27223a-ae84-11ef-8569-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 19:03:28	2024-11-29 19:03:35	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
247346fc-ae85-11ef-856a-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 19:07:13	2024-11-29 19:21:17	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
12c05774-afed-11ef-8d96-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-01 14:03:42	2024-12-01 14:03:51	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
1d6ad922-ae87-11ef-856b-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 19:21:20	2024-12-02 20:00:24	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
08a27ed8-b0e8-11ef-8d97-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-02 20:00:09	2024-12-02 23:03:11	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
9ca70694-b101-11ef-8d98-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-02 23:03:15	2024-12-04 20:49:11	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
33a2f208-b281-11ef-8d99-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-04 20:49:05	2024-12-05 16:34:32	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
d0a3fc64-b326-11ef-8d9a-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-05 16:34:36	2024-12-06 16:33:02	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
b8c66cd4-b3ef-11ef-8d9b-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-06 16:32:45	2024-12-06 16:33:02	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
bea02a46-b3ef-11ef-8d9c-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-06 16:32:54	2024-12-07 19:37:13	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
ac93d878-b4d2-11ef-8d9d-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-07 19:37:20	2024-12-09 09:55:10	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
da879020-b5b4-11ef-8d9e-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-08 22:36:23	2024-12-10 14:36:08	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
1b03b250-b704-11ef-8da0-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-10 14:36:13	2024-12-10 16:20:16	\N	833952d4-ae81-11ef-8565-2cf05d44ba6c	20	50	10	\N	\N
1999e1f0-b704-11ef-8d9f-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-10 14:36:10	2024-12-22 19:39:25	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
16d681f0-c09e-11ef-a5f8-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-22 19:51:09	2024-12-22 19:51:22	\N	96b15708-ae81-11ef-8566-2cf05d44ba6c	20	50	10	\N	\N
278ff63e-c09e-11ef-a5f9-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-22 19:51:37	2024-12-22 19:51:42	\N	96b15708-ae81-11ef-8566-2cf05d44ba6c	20	50	10	\N	\N
53a4cd5a-c0a6-11ef-a5fa-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-22 20:50:07	2024-12-22 20:50:17	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
36440e08-c180-11ef-adf4-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-23 22:49:48	2024-12-23 22:49:54	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
6aa1ec90-c09c-11ef-a5f7-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-22 19:39:11	2024-12-23 22:50:13	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
42843a3a-c180-11ef-adf5-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-23 22:50:08	2024-12-23 22:50:13	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
5652f752-c0a6-11ef-a5fb-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-22 20:50:12	2024-12-24 10:21:43	\N	833952d4-ae81-11ef-8565-2cf05d44ba6c	20	50	10	\N	\N
3632f1f8-c1ea-11ef-adf7-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-24 11:28:34	2024-12-24 11:28:38	\N	833952d4-ae81-11ef-8565-2cf05d44ba6c	20	50	10	\N	\N
dca02b50-c1e0-11ef-adf6-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-24 10:21:39	2024-12-24 17:53:38	\N	68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	20	50	10	\N	\N
0c09add6-c2d5-11ef-b321-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-25 15:29:35	2024-12-25 18:32:20	\N	96b15708-ae81-11ef-8566-2cf05d44ba6c	20	50	10	\N	\N
d1123088-c2f0-11ef-b335-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-25 18:48:22	2024-12-25 18:48:33	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	20	50	10	\N	\N
d4c072d0-c2f0-11ef-b336-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-25 18:48:28	2024-12-25 18:48:41	\N	833952d4-ae81-11ef-8565-2cf05d44ba6c	20	50	10	\N	\N
028eceea-c220-11ef-b316-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-24 17:53:40	2024-12-29 18:21:52	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
d9e7d564-c2f0-11ef-b337-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-25 18:48:37	2024-12-29 18:21:52	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
cb55bd62-c611-11ef-b353-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-29 18:22:00	2024-12-29 18:22:28	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
98ba99c0-c2ee-11ef-b334-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-25 18:32:29	2024-12-30 21:09:51	\N	96b15708-ae81-11ef-8566-2cf05d44ba6c	20	50	10	\N	\N
d6a52752-c611-11ef-b354-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-29 18:22:19	2024-12-30 21:09:51	\N	96b15708-ae81-11ef-8566-2cf05d44ba6c	20	50	10	\N	\N
6c52f53c-c6f2-11ef-b355-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-30 21:09:57	2024-12-30 21:10:03	\N	4d478746-ab79-11ef-9bef-2cf05d44ba6c	20	50	10	\N	\N
349e7260-c792-11ef-b357-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-31 16:13:43	\N	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	10	50	\N	\N	\N
73bfb38c-c6f2-11ef-b356-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-12-30 21:10:09	2024-12-31 16:13:55	\N	833952d4-ae81-11ef-8565-2cf05d44ba6c	20	50	10	\N	\N
eeb6eb16-c876-11ef-b358-2cf05d44ba6c	Vandorpe Wouter PHP Task Portal	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2025-01-01 19:31:01	\N	\N	05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	10	50	\N	\N	\N
7f0c3dca-a139-11ef-9b31-2cf05d44ba6c	System Machine_01	a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c	{a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c}	2017-11-12 22:02:58	2023-11-12 22:03:16	0	6742d11e-ab79-11ef-9bf0-2cf05d44ba6c	20	40	10		2000-01-01 00:00:00
cfc13d98-a390-11ef-926b-2cf05d44ba6c	System Machine_01	a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c	{a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c}	2024-11-15 21:33:02	2024-11-15 21:33:11	0	833952d4-ae81-11ef-8565-2cf05d44ba6c	20	40	10		2000-01-01 00:00:00
\.


--
-- Data for Name: paper; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.paper (pkey, name, created_on, comment) FROM stdin;
0944f376-0d6c-11f0-8cea-2cf05d44ba6c	De Morgen	2025-03-30 15:36:42.8	
0d76305e-0d6c-11f0-8ceb-2cf05d44ba6c	De Tijd	2025-03-30 15:36:53.317	
123de64a-0d6c-11f0-8cec-2cf05d44ba6c	De Standaard	2025-03-30 15:37:00.44	
1788c0ac-0d6c-11f0-8ced-2cf05d44ba6c	Het Nieuwsblad	2025-03-30 15:37:08.3	
\.


--
-- Data for Name: planning; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.planning (pkey, name, created_on, overlap_time, pre_prep, post_prep, planning_shift) FROM stdin;
c767f664-e328-11ef-a3d9-2cf05d44ba6c	Planning_01	2025-02-04 19:48:40	5	15	10	5fec57f4-e324-11ef-a3d7-2cf05d44ba6c
e65fbfde-e328-11ef-a3da-2cf05d44ba6c	Planning_02	2025-02-04 19:50:03	10	20	5	9cf5b4ec-e324-11ef-a3d8-2cf05d44ba6c
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.product (pkey, name, created_on, previous_workstep, current_workstep, next_workstep, product_state, product_ws_state, product_index) FROM stdin;
d8f3f1b8-e7f5-11ef-8490-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.464	\N	\N	\N	0	0	1
d8f60f2a-e7f5-11ef-8491-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.476	\N	\N	\N	0	0	2
d8f6927e-e7f5-11ef-8492-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.48	\N	\N	\N	0	0	3
d8f6faca-e7f5-11ef-8493-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.483	\N	\N	\N	0	0	4
d8f6facb-e7f5-11ef-8494-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.484	\N	\N	\N	0	0	5
d8f6facc-e7f5-11ef-8495-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.484	\N	\N	\N	0	0	6
d8f6facd-e7f5-11ef-8496-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.484	\N	\N	\N	0	0	7
d8f8616c-e7f5-11ef-8497-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.493	\N	\N	\N	0	0	8
d8f8616d-e7f5-11ef-8498-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.493	\N	\N	\N	0	0	9
d8f9c796-e7f5-11ef-8499-2cf05d44ba6c	Batch_02	2025-02-10 22:27:36.501	\N	\N	\N	0	0	10
1252609e-e598-11ef-a3e0-2cf05d44ba6c	Batch_01	2025-02-10 21:00:06.531	4d13e1d4-e670-11ef-ac52-2cf05d44ba6c	661b545a-e670-11ef-ac53-2cf05d44ba6c	\N	10	0	2
1251aece-e598-11ef-a3df-2cf05d44ba6c	Batch_01	2025-02-10 21:00:34.501	2fc4ba9a-e670-11ef-ac51-2cf05d44ba6c	4d13e1d4-e670-11ef-ac52-2cf05d44ba6c	661b545a-e670-11ef-ac53-2cf05d44ba6c	10	10	1
1252ee10-e598-11ef-a3e1-2cf05d44ba6c	Batch_01	2025-02-07 22:11:17.333	2fc4ba9a-e670-11ef-ac51-2cf05d44ba6c	4d13e1d4-e670-11ef-ac52-2cf05d44ba6c	661b545a-e670-11ef-ac53-2cf05d44ba6c	10	10	3
\.


--
-- Data for Name: rti_add_chef; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.rti_add_chef (pkey, name, source_type, source_file, method_name, employee, person) FROM stdin;
\.


--
-- Data for Name: rti_add_customer; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.rti_add_customer (pkey, name, source_type, source_file, method_name, employee, person) FROM stdin;
\.


--
-- Data for Name: rti_add_phone; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.rti_add_phone (pkey, name, source_type, source_file, method_name, employee, person) FROM stdin;
974af782-a11b-11ef-9b2a-2cf05d44ba6c	Phone_01_messageToAddPhoneNumber	PYTHON	RTI_ADD_PHONE.py	messageToAddPhoneNumber	c7399988-a113-11ef-8fe2-2cf05d44ba6c	f2d9c688-a106-11ef-8fdc-2cf05d44ba6c
efa26564-a11b-11ef-9b2c-2cf05d44ba6c	Phone_03	PYTHON	RTI_ADD_PHONE.py	deletePhoneNumber	c7399988-a113-11ef-8fe2-2cf05d44ba6c	f2d9c688-a106-11ef-8fdc-2cf05d44ba6c
ccc8864a-a11b-11ef-9b2b-2cf05d44ba6c	Phone_02_checkIfEmployerExists	PYTHON	RTI_ADD_PHONE.py	checkIfEmployerExists	c7399988-a113-11ef-8fe2-2cf05d44ba6c	f2d9c688-a106-11ef-8fdc-2cf05d44ba6c
\.


--
-- Data for Name: shift; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.shift (pkey, name, created_on, shift_start_monday, shift_start_tuesday, shift_start_wednesday, shift_start_thursday, shift_start_friday, shift_start_saturday, shift_start_sunday, shift_stop_monday, shift_stop_tuesday, shift_stop_wednesday, shift_stop_thursday, shift_stop_friday, shift_stop_saturday, shift_stop_sunday) FROM stdin;
9cf5b4ec-e324-11ef-a3d8-2cf05d44ba6c	Shift_02	2025-02-04 07:00:18	2025-02-04 07:00:18	2025-02-04 08:00:18	2025-02-04 08:00:18	2025-02-04 08:00:18	2025-02-04 07:00:18	2025-02-04 07:00:18	2025-02-04 08:00:18	2025-02-04 18:30:18	2025-02-04 19:30:18	2025-02-04 17:30:18	2025-02-04 18:00:18	2025-02-04 20:00:18	2025-02-04 20:00:18	2025-02-04 20:00:18
5fec57f4-e324-11ef-a3d7-2cf05d44ba6c	Shift_01	2025-02-04 19:14:23	2025-02-04 07:30:23	2025-02-04 08:00:23	2025-02-04 06:15:23	2025-02-04 08:30:23	2025-02-04 06:00:23	2025-02-04 00:00:23	2025-02-04 00:00:23	2025-02-04 19:15:23	2025-02-04 20:00:23	2025-02-04 16:00:23	2025-02-04 17:30:23	2025-02-04 19:00:23	2025-02-04 00:00:23	2025-02-04 00:00:23
\.


--
-- Data for Name: workstep; Type: TABLE DATA; Schema: public; Owner: poststress
--

COPY public.workstep (pkey, name, ws_tech, ws_assigned, ws_workplace, created_on, ws_state, ws_performed_by, ws_planned_start, ws_planned_stop, linked_documents, ws_mach_group, ws_include_planning) FROM stdin;
6742d11e-ab79-11ef-9bf0-2cf05d44ba6c	Meeting-01	200	1bee2fac-ab78-11ef-9bec-2cf05d44ba6c	\N	2024-11-25 23:05:00	\N	\N	\N	\N	\N	\N	\N
12785830-a114-11ef-8fe6-2cf05d44ba6c	Cooking-01	500	5004e9b6-ab78-11ef-9bee-2cf05d44ba6c	\N	2024-12-24 23:52:34	0	\N	2024-12-24 23:52:34	2024-12-24 23:52:34	{cb71668c-c249-11ef-b31d-2cf05d44ba6c,ceaf7c3a-c249-11ef-b31e-2cf05d44ba6c}	\N	\N
4d478746-ab79-11ef-9bef-2cf05d44ba6c	Research-01	300	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-25 23:04:29	20	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	\N	{21a74f9a-c2f8-11ef-b343-2cf05d44ba6c}	\N	\N
833952d4-ae81-11ef-8565-2cf05d44ba6c	Research-03	300	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	2024-11-29 19:40:38	30	c7399988-a113-11ef-8fe2-2cf05d44ba6c	2024-11-29 19:40:38	2024-11-29 19:40:38	{0ae1cc86-c302-11ef-b349-2cf05d44ba6c,f2a2ccc4-c310-11ef-b34b-2cf05d44ba6c}	\N	\N
05fa7ce6-a114-11ef-8fe5-2cf05d44ba6c	Cleaning-01	10	27d75404-ab75-11ef-82ff-2cf05d44ba6c	\N	2024-11-25 23:02:55	10	c7399988-a113-11ef-8fe2-2cf05d44ba6c	\N	\N	{269383f4-c2f1-11ef-b338-2cf05d44ba6c,269383f4-c2f1-11ef-b338-2cf05d44ba6c,2f29863a-c2f1-11ef-b339-2cf05d44ba6c,0f835b7e-c2f8-11ef-b342-2cf05d44ba6c,87348196-c2ff-11ef-b346-2cf05d44ba6c,a69bad72-c30c-11ef-b34a-2cf05d44ba6c,98d79102-c3b5-11ef-b352-2cf05d44ba6c}	\N	\N
96b15708-ae81-11ef-8566-2cf05d44ba6c	Cleaning-02	27	27d75404-ab75-11ef-82ff-2cf05d44ba6c	\N	2024-11-29 19:41:20	30	c7399988-a113-11ef-8fe2-2cf05d44ba6c	2024-11-29 19:41:20	2024-11-29 19:41:20	{8eed37be-c2d9-11ef-b32e-2cf05d44ba6c,8eed37be-c2d9-11ef-b32e-2cf05d44ba6c,7e18fff0-c2f6-11ef-b33e-2cf05d44ba6c,bb5ab610-c2f6-11ef-b33f-2cf05d44ba6c,c0fba688-c2f6-11ef-b340-2cf05d44ba6c,f463cb4e-c2f7-11ef-b341-2cf05d44ba6c,2321dfbe-c2fa-11ef-b344-2cf05d44ba6c,a4fb001a-c2ff-11ef-b347-2cf05d44ba6c,0538d61c-c36b-11ef-b34d-2cf05d44ba6c,1d61df66-d902-11ef-9a74-2cf05d44ba6c}	\N	\N
2fc4ba9a-e670-11ef-ac51-2cf05d44ba6c	Batch_01_WS01	300	\N	\N	2025-02-08 23:56:42	0	\N	2025-02-08 23:56:42	2025-02-08 23:56:42	{}	40c3264c-e323-11ef-a3d1-2cf05d44ba6c	1
68f6f0f2-ae81-11ef-8564-2cf05d44ba6c	Research-02	300	f80ad068-ab77-11ef-9beb-2cf05d44ba6c	a7fb4e8e-a106-11ef-8fd9-2cf05d44ba6c	2024-11-29 19:39:42	0	c7399988-a113-11ef-8fe2-2cf05d44ba6c	2024-11-29 19:39:42	2024-11-29 19:39:42	{385cc5d0-c2e4-11ef-b333-2cf05d44ba6c}	\N	\N
4d13e1d4-e670-11ef-ac52-2cf05d44ba6c	Batch_01_WS02	0	\N	\N	2025-02-08 23:58:25	0	\N	2019-02-08 23:58:25	2025-02-08 23:58:25	{}	4f518988-e323-11ef-a3d2-2cf05d44ba6c	1
661b545a-e670-11ef-ac53-2cf05d44ba6c	Batch_01_WS03	200	\N	\N	2025-02-08 23:59:10	0	\N	2025-02-08 23:59:10	2025-02-08 23:59:10	{}	57541f56-e323-11ef-a3d3-2cf05d44ba6c	1
\.


--
-- Name: a_allergy a_allergy_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_allergy
    ADD CONSTRAINT a_allergy_pkey PRIMARY KEY (pkey);


--
-- Name: a_batch a_batch_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_batch
    ADD CONSTRAINT a_batch_pkey PRIMARY KEY (pkey);


--
-- Name: a_customer a_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_customer
    ADD CONSTRAINT a_customer_pkey PRIMARY KEY (pkey);


--
-- Name: a_cycle_routine a_cycle_routine_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_cycle_routine
    ADD CONSTRAINT a_cycle_routine_pkey PRIMARY KEY (pkey);


--
-- Name: a_cycles a_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_cycles
    ADD CONSTRAINT a_cycles_pkey PRIMARY KEY (pkey);


--
-- Name: a_diet a_diet_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_diet
    ADD CONSTRAINT a_diet_pkey PRIMARY KEY (pkey);


--
-- Name: a_does_not_like a_does_not_like_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_does_not_like
    ADD CONSTRAINT a_does_not_like_pkey PRIMARY KEY (pkey);


--
-- Name: a_empl_group a_empl_group_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_empl_group
    ADD CONSTRAINT a_empl_group_pkey PRIMARY KEY (pkey);


--
-- Name: a_employee a_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_employee
    ADD CONSTRAINT a_employee_pkey PRIMARY KEY (pkey);


--
-- Name: a_errors_living_obj_mach a_errors_living_obj_mach_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_errors_living_obj_mach
    ADD CONSTRAINT a_errors_living_obj_mach_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_bread a_food_bread_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_bread
    ADD CONSTRAINT a_food_bread_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_breakfast a_food_breakfast_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_breakfast
    ADD CONSTRAINT a_food_breakfast_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_butter a_food_butter_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_butter
    ADD CONSTRAINT a_food_butter_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_charcuterie a_food_charcuterie_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_charcuterie
    ADD CONSTRAINT a_food_charcuterie_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_dessert a_food_dessert_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_dessert
    ADD CONSTRAINT a_food_dessert_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_dinner a_food_dinner_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_dinner
    ADD CONSTRAINT a_food_dinner_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_drink a_food_drink_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_drink
    ADD CONSTRAINT a_food_drink_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_drinkserivce a_food_drinkserivce_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_drinkserivce
    ADD CONSTRAINT a_food_drinkserivce_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_lunch a_food_lunch_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_lunch
    ADD CONSTRAINT a_food_lunch_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_place a_food_place_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_place
    ADD CONSTRAINT a_food_place_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_portion a_food_portion_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_portion
    ADD CONSTRAINT a_food_portion_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_sugar a_food_sugar_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_sugar
    ADD CONSTRAINT a_food_sugar_pkey PRIMARY KEY (pkey);


--
-- Name: a_food_texture a_food_texture_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_food_texture
    ADD CONSTRAINT a_food_texture_pkey PRIMARY KEY (pkey);


--
-- Name: a_linkeddoc a_linkeddoc_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_linkeddoc
    ADD CONSTRAINT a_linkeddoc_pkey PRIMARY KEY (pkey);


--
-- Name: a_living_obj_mach a_living_obj_mach_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_living_obj_mach
    ADD CONSTRAINT a_living_obj_mach_pkey PRIMARY KEY (pkey);


--
-- Name: a_mach_group a_mach_group_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_mach_group
    ADD CONSTRAINT a_mach_group_pkey PRIMARY KEY (pkey);


--
-- Name: a_operation a_operation_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_operation
    ADD CONSTRAINT a_operation_pkey PRIMARY KEY (pkey);


--
-- Name: a_paper a_paper_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_paper
    ADD CONSTRAINT a_paper_pkey PRIMARY KEY (pkey);


--
-- Name: a_planning a_planning_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_planning
    ADD CONSTRAINT a_planning_pkey PRIMARY KEY (pkey);


--
-- Name: a_product a_product_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_product
    ADD CONSTRAINT a_product_pkey PRIMARY KEY (pkey);


--
-- Name: a_rti_add_chef a_rti_add_chef_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_rti_add_chef
    ADD CONSTRAINT a_rti_add_chef_pkey PRIMARY KEY (pkey);


--
-- Name: a_rti_add_customer a_rti_add_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_rti_add_customer
    ADD CONSTRAINT a_rti_add_customer_pkey PRIMARY KEY (pkey);


--
-- Name: a_rti_add_phone a_rti_add_phone_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_rti_add_phone
    ADD CONSTRAINT a_rti_add_phone_pkey PRIMARY KEY (pkey);


--
-- Name: a_shift a_shift_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_shift
    ADD CONSTRAINT a_shift_pkey PRIMARY KEY (pkey);


--
-- Name: a_workstep a_workstep_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.a_workstep
    ADD CONSTRAINT a_workstep_pkey PRIMARY KEY (pkey);


--
-- Name: allergy allergy_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.allergy
    ADD CONSTRAINT allergy_pkey PRIMARY KEY (pkey);


--
-- Name: batch batch_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.batch
    ADD CONSTRAINT batch_pkey PRIMARY KEY (pkey);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (pkey);


--
-- Name: cycle_routine cycle_routine_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.cycle_routine
    ADD CONSTRAINT cycle_routine_pkey PRIMARY KEY (pkey);


--
-- Name: cycles cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.cycles
    ADD CONSTRAINT cycles_pkey PRIMARY KEY (pkey);


--
-- Name: diet diet_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.diet
    ADD CONSTRAINT diet_pkey PRIMARY KEY (pkey);


--
-- Name: does_not_like does_not_like_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.does_not_like
    ADD CONSTRAINT does_not_like_pkey PRIMARY KEY (pkey);


--
-- Name: empl_group empl_group_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.empl_group
    ADD CONSTRAINT empl_group_pkey PRIMARY KEY (pkey);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (pkey);


--
-- Name: errors_living_obj_mach errors_living_obj_mach_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.errors_living_obj_mach
    ADD CONSTRAINT errors_living_obj_mach_pkey PRIMARY KEY (pkey);


--
-- Name: food_bread food_bread_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_bread
    ADD CONSTRAINT food_bread_pkey PRIMARY KEY (pkey);


--
-- Name: food_breakfast food_breakfast_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_breakfast
    ADD CONSTRAINT food_breakfast_pkey PRIMARY KEY (pkey);


--
-- Name: food_butter food_butter_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_butter
    ADD CONSTRAINT food_butter_pkey PRIMARY KEY (pkey);


--
-- Name: food_charcuterie food_charcuterie_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_charcuterie
    ADD CONSTRAINT food_charcuterie_pkey PRIMARY KEY (pkey);


--
-- Name: food_dessert food_dessert_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_dessert
    ADD CONSTRAINT food_dessert_pkey PRIMARY KEY (pkey);


--
-- Name: food_dinner food_dinner_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_dinner
    ADD CONSTRAINT food_dinner_pkey PRIMARY KEY (pkey);


--
-- Name: food_drink food_drink_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_drink
    ADD CONSTRAINT food_drink_pkey PRIMARY KEY (pkey);


--
-- Name: food_drinkserivce food_drinkserivce_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_drinkserivce
    ADD CONSTRAINT food_drinkserivce_pkey PRIMARY KEY (pkey);


--
-- Name: food_lunch food_lunch_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_lunch
    ADD CONSTRAINT food_lunch_pkey PRIMARY KEY (pkey);


--
-- Name: food_place food_place_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_place
    ADD CONSTRAINT food_place_pkey PRIMARY KEY (pkey);


--
-- Name: food_portion food_portion_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_portion
    ADD CONSTRAINT food_portion_pkey PRIMARY KEY (pkey);


--
-- Name: food_sugar food_sugar_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_sugar
    ADD CONSTRAINT food_sugar_pkey PRIMARY KEY (pkey);


--
-- Name: food_texture food_texture_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.food_texture
    ADD CONSTRAINT food_texture_pkey PRIMARY KEY (pkey);


--
-- Name: linkeddoc linkeddoc_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.linkeddoc
    ADD CONSTRAINT linkeddoc_pkey PRIMARY KEY (pkey);


--
-- Name: living_obj_mach living_obj_mach_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.living_obj_mach
    ADD CONSTRAINT living_obj_mach_pkey PRIMARY KEY (pkey);


--
-- Name: mach_group mach_group_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.mach_group
    ADD CONSTRAINT mach_group_pkey PRIMARY KEY (pkey);


--
-- Name: operation operation_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.operation
    ADD CONSTRAINT operation_pkey PRIMARY KEY (pkey);


--
-- Name: paper paper_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.paper
    ADD CONSTRAINT paper_pkey PRIMARY KEY (pkey);


--
-- Name: planning planning_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.planning
    ADD CONSTRAINT planning_pkey PRIMARY KEY (pkey);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (pkey);


--
-- Name: rti_add_chef rti_add_chef_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.rti_add_chef
    ADD CONSTRAINT rti_add_chef_pkey PRIMARY KEY (pkey);


--
-- Name: rti_add_customer rti_add_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.rti_add_customer
    ADD CONSTRAINT rti_add_customer_pkey PRIMARY KEY (pkey);


--
-- Name: rti_add_phone rti_add_phone_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.rti_add_phone
    ADD CONSTRAINT rti_add_phone_pkey PRIMARY KEY (pkey);


--
-- Name: shift shift_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.shift
    ADD CONSTRAINT shift_pkey PRIMARY KEY (pkey);


--
-- Name: workstep workstep_pkey; Type: CONSTRAINT; Schema: public; Owner: poststress
--

ALTER TABLE ONLY public.workstep
    ADD CONSTRAINT workstep_pkey PRIMARY KEY (pkey);


--
-- PostgreSQL database dump complete
--

