/********************************************************************************
** Form generated from reading UI file 'wdgDatabaseEditor.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef WDGDATABASEEDITOR_H
#define WDGDATABASEEDITOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wdgDatabaseEditor
{
public:
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QTextEdit *txtInfo;
    QProgressBar *pgbProgress;

    void setupUi(QWidget *wdgDatabaseEditor)
    {
        if (wdgDatabaseEditor->objectName().isEmpty())
            wdgDatabaseEditor->setObjectName(QString::fromUtf8("wdgDatabaseEditor"));
        wdgDatabaseEditor->resize(684, 298);
        scrollArea = new QScrollArea(wdgDatabaseEditor);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(10, 50, 661, 201));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 659, 199));
        txtInfo = new QTextEdit(scrollAreaWidgetContents);
        txtInfo->setObjectName(QString::fromUtf8("txtInfo"));
        txtInfo->setGeometry(QRect(3, 3, 651, 191));
        scrollArea->setWidget(scrollAreaWidgetContents);
        pgbProgress = new QProgressBar(wdgDatabaseEditor);
        pgbProgress->setObjectName(QString::fromUtf8("pgbProgress"));
        pgbProgress->setGeometry(QRect(10, 260, 661, 23));
        pgbProgress->setValue(24);

        retranslateUi(wdgDatabaseEditor);

        QMetaObject::connectSlotsByName(wdgDatabaseEditor);
    } // setupUi

    void retranslateUi(QWidget *wdgDatabaseEditor)
    {
        wdgDatabaseEditor->setWindowTitle(QApplication::translate("wdgDatabaseEditor", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class wdgDatabaseEditor: public Ui_wdgDatabaseEditor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // WDGDATABASEEDITOR_H
