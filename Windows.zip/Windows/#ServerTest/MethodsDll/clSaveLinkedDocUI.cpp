#define INFO_BUFFER_SIZE 32767
#include "clSaveLinkedDocUI.h"

clSaveLinkedDocUI::clSaveLinkedDocUI(clIceClientServer * paIceClientServer, clIceClientLogging * paIceClientLogging, QWidget* paParent, const char* paName)
{
    meIceClientLogging = paIceClientLogging;
    meIceClientServer = paIceClientServer;
    
    meMainLayout = new QVBoxLayout();
	
	meLabels[0] = new QLabel;
	meLabels[0]->setText(QString("Select the file to save ..."));

	meButtons[1] = new QPushButton(tr("Close"));
	meButtons[0] = new QPushButton(tr("Select file"));
	connect(meButtons[0], SIGNAL(clicked()), this, SLOT(slotButtonSaveAssPressed()));
    connect(meButtons[1], SIGNAL(clicked()), this, SLOT(slotButtonCancelPressed()));
	
    meMainLayout->addWidget(meLabels[0]);
	
	meMainLayout->addWidget(meButtons[0]);
	meMainLayout->addWidget(meButtons[1]);
    setLayout(meMainLayout);
	
	setWindowFlags(Qt::Dialog | Qt::CustomizeWindowHint | Qt::WindowTitleHint);
	//QApplication::setQuitOnLastWindowClosed(false);
}
clSaveLinkedDocUI::~clSaveLinkedDocUI()
{
}
void clSaveLinkedDocUI::slotButtonSaveAssPressed()
{
	// Get and display the name of the computer.
	TCHAR infoBuf[INFO_BUFFER_SIZE];
	DWORD  bufCharCount = INFO_BUFFER_SIZE;
	GetComputerName(infoBuf,&bufCharCount);	
    try
    {
		
        QString fname = QFileDialog::getOpenFileName(this,tr("Select file"), "", tr("Image Files (*.*)"));
		
		string loFileStruct;
		
		if (!meIceClientServer->getServerFileStructure(loFileStruct))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> Could not get the file structure path ...");
			return;
		}
		

		
		
		//Check if the file exists
		QFile loCheck(fname);
		QFileInfo loCheck_file(fname);
		
		

		
		//Create linked doc
		QString loReturnMessage;
		vector<std::string> loColumns;
		vector<std::string> loValue;
		vector<std::string> loTypeValue;
		
		loColumns.push_back("NAME");
		loColumns.push_back("CREATED_ON");
		loColumns.push_back("FILE_NAME");		
		loColumns.push_back("FILE_TYPE");
		
		QDateTime dateTime = QDateTime::currentDateTime();
		
		loValue.push_back(loCheck_file.fileName().toStdString());
		loValue.push_back(QString(dateTime.toString("yyyy-MM-dd HH:mm:ss.zzz")).toStdString());
		loValue.push_back(loCheck_file.fileName().toStdString());
		loValue.push_back("0");
		
		loTypeValue.push_back("text");
		loTypeValue.push_back("timestamp(3)");
		loTypeValue.push_back("text");
		loTypeValue.push_back("int");
		
		
		if (!meIceClientServer->insertIntoTableDatabase( 	QString("LINKEDDOC"),
															loColumns,
															loValue,
															loTypeValue,
															loReturnMessage))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessage);
			return;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessage);
		
		//Get the linked doc
		QString loTableName("cycles");
		vector <std::string> loProperties;
		vector <std::string> loValues;
		vector <std::string> loTypeValues;
		vector <std::string> loLogExp;
		vector <std::string> loReturnIds;
		QString loReturnMessageGet;
		
		loProperties.push_back("NAME");
		loProperties.push_back("CREATED_ON");
		loProperties.push_back("FILE_NAME");
		loProperties.push_back("FILE_TYPE");

		loValues.push_back(loCheck_file.fileName().toStdString());
		loValues.push_back(QString(dateTime.toString("yyyy-MM-dd HH:mm:ss.zzz")).toStdString());
		loValues.push_back(loCheck_file.fileName().toStdString());
		loValues.push_back("0");
		
		loTypeValues.push_back("text");
		loTypeValues.push_back("timestamp(3)");
		loTypeValues.push_back("text");
		loTypeValues.push_back("int");		
		
		loLogExp.push_back("=");
		loLogExp.push_back("=");
		loLogExp.push_back("=");
		loLogExp.push_back("=");
		
		
		if (!meIceClientServer->getFromTableDatbaseByProperty(QString("LINKEDDOC"),QString("0"),QString("0"),loProperties,loValues,loTypeValues,loLogExp,loReturnIds,loReturnMessageGet))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessageGet);
			return;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessageGet);		
		
		if (loReturnIds.size() == 0)
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> No linked doc result found ...");
			return;			
		}



		QDir pathDir(QString(loFileStruct.c_str()) + QString("LINKEDDOC_") + QString(loReturnIds.at(0).c_str()));
		if (!pathDir.exists())
		{
			QDir().mkdir(QString(loFileStruct.c_str()) + QString("LINKEDDOC_") + QString(loReturnIds.at(0).c_str()));
		}

		
		
		//Copy the file
		QFileInfo loTarget_file(QString(loFileStruct.c_str()) + QString("LINKEDDOC_") + QString(loReturnIds.at(0).c_str()) + QString("\\") + loCheck_file.fileName());
		if (loTarget_file.exists() && loTarget_file.isFile()) 
		{ 
			QFile loFile (QString(loFileStruct.c_str()) + QString("LINKEDDOC_") + QString(loReturnIds.at(0).c_str()) + QString("\\") + loCheck_file.fileName());
			loFile.remove();	
		}		
		loCheck.copy(QString(loFileStruct.c_str()) + QString("LINKEDDOC_") + QString(loReturnIds.at(0).c_str()) + QString("\\") + loCheck_file.fileName());
		
		//Getting the current linked documents
		vector<std::string> loColumnsBeforeUpd;
        vector<std::string> loValueBeforeUpd;
		QString loReturnMessageBeforeUpd;
		
		
		
		loColumnsBeforeUpd.push_back("LINKED_DOCUMENTS");
		
		if(!meIceClientServer->getFromTableDatabaseById(    meTableName,
															meObjectId,
															loColumnsBeforeUpd,
															loValueBeforeUpd,
															loReturnMessageBeforeUpd))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessageBeforeUpd);		
			return;			
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessageBeforeUpd);		
		
		if (loValueBeforeUpd.size() == 0)
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> No property LINKED_DOCUMENTS result on object" + QString(meTableName + QString("_") + meObjectId));
			return;			
		}


		QStringList loElements = QString(loValueBeforeUpd.at(0).c_str()).remove("}").remove("{").split(",", QString::SkipEmptyParts);
		QString loResult = QString("");
				 
		for (int k = 0; k < loElements.size(); k++)
		{
			if (k == 0)
				loResult = loResult + loElements.at(k);
			else
				loResult = loResult + QString("$;$") + loElements.at(k);
		}





	
		//Updating the object
        vector<std::string> loColumnsUpd;
        vector<std::string> loValueUpd;
        vector<std::string> loTypeValueUpd;
        QString loReturnMessageUpd;


		if (loResult.compare(QString("")) == 0)
			loResult = QString(loReturnIds.at(0).c_str());
		else
			loResult = loResult + QString("$;$") + QString(loReturnIds.at(0).c_str());



		loColumnsUpd.push_back("LINKED_DOCUMENTS");
		loValueUpd.push_back(loResult.toStdString());
		loTypeValueUpd.push_back("uuid[]");
        if (!meIceClientServer->updateIntoTableDatabase(     meTableName,
                                                        meObjectId,
                                                        loColumnsUpd,
                                                        loValueUpd,
                                                        loTypeValueUpd,
                                                        loReturnMessageUpd))
		{
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessageUpd);		
			return;
		}
		else
			meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + loReturnMessageUpd);				
	
		
		
		
		
		
		
		
		
		
    }
    catch(exception &e)
    {
			
		
		
        meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonSaveAssPressed() -> " + QString(e.what()));
    }
}

void clSaveLinkedDocUI::slotButtonCancelPressed()
{
    try
    {	
	
        this->done(1);
    }
    catch(exception &e)
    {
		// Get and display the name of the computer.
		TCHAR infoBuf[INFO_BUFFER_SIZE];
		DWORD  bufCharCount = INFO_BUFFER_SIZE;
		GetComputerName(infoBuf,&bufCharCount);			
		
        meIceClientLogging->insertItem("10",QString(infoBuf),"2UVServerTest.exe","clSaveLinkedDocUI::slotButtonCancelPressed() -> " + QString(e.what()));
    }
}


